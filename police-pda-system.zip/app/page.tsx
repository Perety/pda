import PDASystem from "@/components/pda-system"

export default function Page() {
  return <PDASystem />
}
