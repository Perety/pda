export interface Servidor {
  id: string
  nombre: string
  codigo: string
  activo: boolean
}

export interface Usuario {
  id: string
  nombre: string
  username: string
  password: string
  placa?: string
  rango?: string
  rol: 'oficial' | 'admin' | 'superadmin'
  servidor_id: string
  activo: boolean
  servidores?: Servidor
}

export interface Ciudadano {
  id: string
  nombre: string
  dni: string
  telefono?: string
  direccion?: string
  notas?: string
  servidor_id: string
  oficial_registro: string
  created_at: string
}

export interface Vehiculo {
  id: string
  matricula: string
  marca?: string
  modelo?: string
  color?: string
  propietario_nombre?: string
  estado: 'Normal' | 'Buscado' | 'Robado'
  notas?: string
  servidor_id: string
  oficial_registro: string
  created_at: string
}

export interface Multa {
  id: string
  ciudadano_nombre: string
  importe: number
  motivo: string
  oficial_nombre: string
  oficial_id: string
  servidor_id: string
  estado: string
  created_at: string
}

export interface Arresto {
  id: string
  ciudadano_nombre: string
  tiempo: number
  fianza?: number
  cargos: string
  oficial_nombre: string
  oficial_id: string
  servidor_id: string
  estado: string
  created_at: string
}

export interface Llamada {
  id: string
  tipo: string
  ubicacion: string
  descripcion?: string
  servidor_id: string
  creado_por: string
  estado: string
  created_at: string
}

export interface Bolo {
  id: string
  titulo: string
  tipo: string
  descripcion: string
  activo: boolean
  servidor_id: string
  creado_por: string
  estado: string
  created_at: string
}

export interface Denuncia {
  id: string
  victima: string
  acusado?: string
  narracion: string
  servidor_id: string
  oficial_receptor: string
  created_at: string
}

export interface Investigacion {
  id: string
  titulo: string
  descripcion: string
  estado: string
  servidor_id: string
  detective_lider: string
  investigador_id: string
  created_at: string
}

export interface Servicio {
  id: string
  usuario_id: string
  servidor_id: string
  hora_inicio: string
  hora_fin?: string
  estado: 'disponible' | 'ocupado' | 'descanso' | 'offline'
  usuarios?: Usuario
}

export interface Auditoria {
  id: string
  usuario_id: string
  usuario_nombre: string
  servidor_id: string
  accion: string
  modulo: string
  descripcion?: string
  detalles?: string
  fecha_hora: string
}

export type ThemeColor = 'cyan' | 'blue' | 'green' | 'purple' | 'red'
