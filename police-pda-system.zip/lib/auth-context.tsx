"use client"

import { createContext, useContext, useState, useCallback, useEffect, useRef, type ReactNode } from "react"
import type { Usuario, ThemeColor } from "@/lib/types"
import { createClient } from "@/lib/supabase/client"

interface AuthContextType {
  user: Usuario | null
  serverId: string | null
  activeServiceId: string | null
  theme: ThemeColor
  login: (serverId: string, username: string, password: string) => Promise<{ success: boolean; error?: string }>
  logout: () => void
  setActiveServiceId: (id: string | null) => void
  setTheme: (theme: ThemeColor) => void
  checkActiveService: () => Promise<void>
  isReady: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

function getSupabaseClient() {
  return createClient()
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<Usuario | null>(null)
  const [serverId, setServerId] = useState<string | null>(null)
  const [activeServiceId, setActiveServiceId] = useState<string | null>(null)
  const [theme, setThemeState] = useState<ThemeColor>("cyan")
  const [isReady, setIsReady] = useState(false)

  useEffect(() => {
    const savedTheme = localStorage.getItem("pda-theme") as ThemeColor
    if (savedTheme) {
      setThemeState(savedTheme)
      document.documentElement.setAttribute("data-theme", savedTheme)
    }
    setIsReady(true)
  }, [])

  const setTheme = useCallback((newTheme: ThemeColor) => {
    setThemeState(newTheme)
    localStorage.setItem("pda-theme", newTheme)
    document.documentElement.setAttribute("data-theme", newTheme)
  }, [])

  const checkActiveService = useCallback(async () => {
    if (!user) return
    const supabase = getSupabaseClient()
    const { data } = await supabase
      .from("servicio")
      .select("id")
      .eq("usuario_id", user.id)
      .is("hora_fin", null)
      .maybeSingle()
    if (data) setActiveServiceId(data.id)
  }, [user])

  const login = useCallback(async (sid: string, username: string, password: string) => {
    const supabase = getSupabaseClient()
    
    const { data, error } = await supabase
      .from("usuarios")
      .select("*, servidores(nombre, codigo)")
      .eq("username", username)
      .eq("password", password)
      .eq("servidor_id", sid)
      .maybeSingle()

    if (error || !data) {
      return { success: false, error: "Credenciales inválidas o usuario inactivo" }
    }

    if (data.activo === false) {
      return { success: false, error: "Usuario desactivado. Contacta administración." }
    }

    setUser(data as Usuario)
    setServerId(sid)
    return { success: true }
  }, [])

  const logout = useCallback(() => {
    setUser(null)
    setServerId(null)
    setActiveServiceId(null)
  }, [])

  return (
    <AuthContext.Provider
      value={{
        user,
        serverId,
        activeServiceId,
        theme,
        login,
        logout,
        setActiveServiceId,
        setTheme,
        checkActiveService,
        isReady,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
