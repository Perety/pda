"use client"

import type { ReactNode } from "react"

// Stat Card
interface StatCardProps {
  title: string
  value: number | string
  icon: ReactNode
  color?: "accent" | "success" | "warning" | "danger"
}

export function StatCard({ title, value, icon, color = "accent" }: StatCardProps) {
  const colorClasses = {
    accent: "bg-pda-accent/10 text-pda-accent",
    success: "bg-pda-success/10 text-pda-success",
    warning: "bg-pda-warning/10 text-pda-warning",
    danger: "bg-pda-danger/10 text-pda-danger",
  }

  return (
    <div className="bg-pda-card border border-pda-border rounded-xl p-5 hover:border-pda-accent hover:-translate-y-0.5 transition-all">
      <div className="flex items-center justify-between mb-3">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${colorClasses[color]}`}>
          {icon}
        </div>
      </div>
      <p className="text-xs font-bold text-pda-muted uppercase tracking-wide">{title}</p>
      <p className="text-4xl font-bold text-white mt-1">{value}</p>
    </div>
  )
}

// Section
interface SectionProps {
  title?: string
  actions?: ReactNode
  children: ReactNode
}

export function Section({ title, actions, children }: SectionProps) {
  return (
    <div className="bg-pda-card border border-pda-border rounded-xl p-6 mb-6">
      {(title || actions) && (
        <div className="flex justify-between items-center mb-5 flex-wrap gap-4">
          {title && <h3 className="text-xl font-bold tracking-wide text-white">{title}</h3>}
          {actions && <div className="flex gap-2">{actions}</div>}
        </div>
      )}
      {children}
    </div>
  )
}

// List Item
interface ListItemProps {
  title: ReactNode
  meta?: ReactNode[]
  description?: string
  actions?: ReactNode
  borderColor?: "accent" | "danger" | "warning" | "success"
  tag?: { label: string; color: "danger" | "success" | "warning" | "info" }
}

export function ListItem({ title, meta, description, actions, borderColor, tag }: ListItemProps) {
  const borderClasses = borderColor ? `border-l-4 border-l-pda-${borderColor}` : ""

  return (
    <div className={`bg-pda-hover border border-pda-border rounded-lg p-4 hover:border-pda-accent/30 transition-all ${borderClasses}`}>
      <div className="flex justify-between items-start mb-2">
        <div className="flex-1">
          <div className="text-base font-bold text-white tracking-wide flex items-center gap-2">
            {title}
          </div>
          {meta?.map((m, i) => (
            <div key={i} className="text-sm text-pda-muted font-semibold flex items-center gap-1.5 mt-1">
              {m}
            </div>
          ))}
        </div>
        {tag && <Tag color={tag.color}>{tag.label}</Tag>}
      </div>
      {description && (
        <div className="text-sm text-pda-muted bg-black/20 p-2 rounded-md mt-2 font-medium">
          {description}
        </div>
      )}
      {actions && (
        <div className="flex gap-2 mt-3 pt-3 border-t border-pda-border">{actions}</div>
      )}
    </div>
  )
}

// Tag
interface TagProps {
  children: ReactNode
  color: "danger" | "success" | "warning" | "info"
}

export function Tag({ children, color }: TagProps) {
  const colorClasses = {
    danger: "bg-pda-danger/20 text-pda-danger border-pda-danger",
    success: "bg-pda-success/20 text-pda-success border-pda-success",
    warning: "bg-pda-warning/20 text-pda-warning border-pda-warning",
    info: "bg-pda-accent/20 text-pda-accent border-pda-accent",
  }

  return (
    <span className={`px-2 py-1 rounded text-xs font-bold uppercase border ${colorClasses[color]}`}>
      {children}
    </span>
  )
}

// Button
interface ButtonProps {
  children: ReactNode
  onClick?: () => void
  type?: "button" | "submit"
  variant?: "default" | "accent" | "danger" | "success" | "warning"
  disabled?: boolean
  className?: string
}

export function Button({ children, onClick, type = "button", variant = "default", disabled, className = "" }: ButtonProps) {
  const baseClasses = "px-4 py-2.5 rounded-md font-bold text-sm uppercase tracking-wide flex items-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
  
  const variantClasses = {
    default: "bg-pda-hover border border-pda-border text-pda-muted hover:bg-pda-card hover:text-white hover:border-pda-accent",
    accent: "bg-gradient-to-r from-pda-accent to-[#0088cc] text-white border-none hover:-translate-y-0.5 hover:shadow-lg hover:shadow-pda-accent/30",
    danger: "bg-pda-danger text-white border-none hover:bg-red-600",
    success: "bg-pda-success text-white border-none hover:brightness-110",
    warning: "bg-pda-warning text-black border-none hover:brightness-110",
  }

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`${baseClasses} ${variantClasses[variant]} ${className}`}
    >
      {children}
    </button>
  )
}

// Input
interface InputProps {
  label: string
  value: string
  onChange: (value: string) => void
  type?: "text" | "password" | "number" | "email"
  placeholder?: string
  required?: boolean
}

export function Input({ label, value, onChange, type = "text", placeholder, required }: InputProps) {
  return (
    <div>
      <label className="block text-xs font-semibold text-pda-muted uppercase tracking-wide mb-2">
        {label} {required && "*"}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        className="w-full p-3 bg-pda-card border border-pda-border rounded-lg text-white text-sm font-medium focus:outline-none focus:border-pda-accent focus:ring-2 focus:ring-pda-accent/20 transition-all"
      />
    </div>
  )
}

// Select
interface SelectProps {
  label: string
  value: string
  onChange: (value: string) => void
  options: { value: string; label: string }[]
  required?: boolean
}

export function Select({ label, value, onChange, options, required }: SelectProps) {
  return (
    <div>
      <label className="block text-xs font-semibold text-pda-muted uppercase tracking-wide mb-2">
        {label} {required && "*"}
      </label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required={required}
        className="w-full p-3 bg-pda-card border border-pda-border rounded-lg text-white text-sm font-medium focus:outline-none focus:border-pda-accent focus:ring-2 focus:ring-pda-accent/20 transition-all"
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
    </div>
  )
}

// Textarea
interface TextareaProps {
  label: string
  value: string
  onChange: (value: string) => void
  placeholder?: string
  required?: boolean
  rows?: number
}

export function Textarea({ label, value, onChange, placeholder, required, rows = 4 }: TextareaProps) {
  return (
    <div>
      <label className="block text-xs font-semibold text-pda-muted uppercase tracking-wide mb-2">
        {label} {required && "*"}
      </label>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        rows={rows}
        className="w-full p-3 bg-pda-card border border-pda-border rounded-lg text-white text-sm font-medium resize-y focus:outline-none focus:border-pda-accent focus:ring-2 focus:ring-pda-accent/20 transition-all"
      />
    </div>
  )
}

// Empty State
interface EmptyStateProps {
  icon: ReactNode
  message: string
}

export function EmptyState({ icon, message }: EmptyStateProps) {
  return (
    <div className="text-center py-12 text-pda-muted">
      <div className="text-5xl mb-4 opacity-50">{icon}</div>
      <p className="text-sm font-semibold">{message}</p>
    </div>
  )
}

// Search Input
interface SearchInputProps {
  value: string
  onChange: (value: string) => void
  placeholder?: string
}

export function SearchInput({ value, onChange, placeholder = "Buscar..." }: SearchInputProps) {
  return (
    <input
      type="text"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="flex-1 min-w-52 p-2.5 bg-pda-hover border border-pda-border rounded-lg text-white text-sm font-medium focus:outline-none focus:border-pda-accent transition-all"
    />
  )
}

// Form Grid
export function FormGrid({ children, cols = 2 }: { children: ReactNode; cols?: 1 | 2 }) {
  return (
    <div className={`grid gap-4 ${cols === 2 ? "md:grid-cols-2" : "grid-cols-1"}`}>
      {children}
    </div>
  )
}

export function FormFullWidth({ children }: { children: ReactNode }) {
  return <div className="md:col-span-2">{children}</div>
}
