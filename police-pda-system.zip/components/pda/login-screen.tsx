"use client"

import React from "react"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"
import type { Servidor } from "@/lib/types"
import { Shield, BookOpen } from "lucide-react"

export function LoginScreen({ onLoginSuccess }: { onLoginSuccess: () => void }) {
  const { login } = useAuth()
  const [servers, setServers] = useState<Servidor[]>([])
  const [serverId, setServerId] = useState("")
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    async function loadServers() {
      try {
        const supabase = createClient()
        const { data, error } = await supabase
          .from("servidores")
          .select("*")
          .eq("activo", true)
          .order("nombre")

        if (!error && data) {
          setServers(data)
        }
      } catch (err) {
        console.error("Error loading servers:", err)
        setError("Error de conexión con la base de datos")
      }
    }
    loadServers()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!serverId || !username || !password) {
      setError("Completa todos los campos")
      return
    }

    setLoading(true)
    const result = await login(serverId, username.trim(), password.trim())
    setLoading(false)

    if (result.success) {
      onLoginSuccess()
    } else {
      setError(result.error || "Error de conexión")
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-pda-primary p-5">
      <div className="bg-pda-secondary border border-pda-border rounded-2xl p-10 w-full max-w-md shadow-pda relative">
        <div className="absolute top-5 right-5 flex gap-3">
          <a
            href="https://discord.gg/8dRQycYGJB"
            target="_blank"
            rel="noopener noreferrer"
            className="w-9 h-9 bg-pda-card border border-pda-border rounded-lg flex items-center justify-center text-pda-muted hover:bg-pda-accent hover:border-pda-accent hover:text-white transition-all hover:-translate-y-0.5"
            title="Discord Soporte"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current">
              <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
            </svg>
          </a>
          <a
            href="https://simnet-sistems-info.vercel.app/"
            target="_blank"
            rel="noopener noreferrer"
            className="w-9 h-9 bg-pda-card border border-pda-border rounded-lg flex items-center justify-center text-pda-muted hover:bg-pda-accent hover:border-pda-accent hover:text-white transition-all hover:-translate-y-0.5"
            title="Documentación"
          >
            <BookOpen className="w-4 h-4" />
          </a>
        </div>

        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-pda-accent to-[#0088cc] rounded-xl flex items-center justify-center text-3xl mx-auto mb-4">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold tracking-wide text-white">SISTEMA PDA POLICIAL</h1>
          <p className="text-pda-muted text-sm font-medium mt-2">Acceso seguro multi-servidor</p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="mb-5">
            <label className="block text-xs font-semibold text-pda-muted uppercase tracking-wide mb-2">
              Servidor
            </label>
            <select
              value={serverId}
              onChange={(e) => setServerId(e.target.value)}
              className="w-full p-3 bg-pda-card border border-pda-border rounded-lg text-white text-base font-medium focus:outline-none focus:border-pda-accent focus:ring-2 focus:ring-pda-accent/20 transition-all"
              required
            >
              <option value="">Selecciona un servidor...</option>
              {servers.map((server) => (
                <option key={server.id} value={server.id}>
                  {server.nombre} ({server.codigo})
                </option>
              ))}
            </select>
          </div>

          <div className="mb-5">
            <label className="block text-xs font-semibold text-pda-muted uppercase tracking-wide mb-2">
              Usuario
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full p-3 bg-pda-card border border-pda-border rounded-lg text-white text-base font-medium focus:outline-none focus:border-pda-accent focus:ring-2 focus:ring-pda-accent/20 transition-all"
              required
              autoComplete="username"
            />
          </div>

          <div className="mb-5">
            <label className="block text-xs font-semibold text-pda-muted uppercase tracking-wide mb-2">
              Contraseña
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-3 bg-pda-card border border-pda-border rounded-lg text-white text-base font-medium focus:outline-none focus:border-pda-accent focus:ring-2 focus:ring-pda-accent/20 transition-all"
              required
              autoComplete="current-password"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-4 bg-gradient-to-r from-pda-accent to-[#0088cc] text-white font-bold text-base uppercase tracking-wider rounded-lg hover:-translate-y-0.5 hover:shadow-lg hover:shadow-pda-accent/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? "CARGANDO..." : "INICIAR SESIÓN"}
          </button>

          {error && (
            <p className="text-red-500 text-sm font-semibold text-center mt-4">{error}</p>
          )}
        </form>
      </div>
    </div>
  )
}
