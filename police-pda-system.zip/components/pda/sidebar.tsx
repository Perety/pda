"use client"

import React from "react"

import { useAuth } from "@/lib/auth-context"
import {
  BarChart3,
  Users,
  Car,
  FileText,
  HandMetal,
  Phone,
  Megaphone,
  ClipboardList,
  Search,
  CircleCheck,
  Gauge,
  UserCog,
  ClipboardCheck,
} from "lucide-react"

export type SectionName =
  | "dashboard"
  | "ciudadanos"
  | "vehiculos"
  | "multas"
  | "arrestos"
  | "llamadas"
  | "bolo"
  | "denuncias"
  | "investigaciones"
  | "servicio"
  | "admin-panel"
  | "admin-usuarios"
  | "auditoria"

interface NavItem {
  id: SectionName
  label: string
  icon: React.ReactNode
  badge?: number
  adminOnly?: boolean
}

const navSections: { title: string; items: NavItem[] }[] = [
  {
    title: "Principal",
    items: [
      { id: "dashboard", label: "Dashboard", icon: <BarChart3 className="w-5 h-5" /> },
      { id: "ciudadanos", label: "Ciudadanos", icon: <Users className="w-5 h-5" /> },
      { id: "vehiculos", label: "Vehículos", icon: <Car className="w-5 h-5" /> },
    ],
  },
  {
    title: "Operaciones",
    items: [
      { id: "multas", label: "Multas", icon: <FileText className="w-5 h-5" /> },
      { id: "arrestos", label: "Arrestos", icon: <HandMetal className="w-5 h-5" /> },
      { id: "llamadas", label: "Llamadas 911", icon: <Phone className="w-5 h-5" /> },
      { id: "bolo", label: "BOLO", icon: <Megaphone className="w-5 h-5" /> },
    ],
  },
  {
    title: "Gestión",
    items: [
      { id: "denuncias", label: "Denuncias", icon: <ClipboardList className="w-5 h-5" /> },
      { id: "investigaciones", label: "Investigaciones", icon: <Search className="w-5 h-5" /> },
      { id: "servicio", label: "En Servicio", icon: <CircleCheck className="w-5 h-5" /> },
    ],
  },
  {
    title: "Administración",
    items: [
      { id: "admin-panel", label: "Panel Admin", icon: <Gauge className="w-5 h-5" />, adminOnly: true },
      { id: "admin-usuarios", label: "Usuarios", icon: <UserCog className="w-5 h-5" />, adminOnly: true },
      { id: "auditoria", label: "Auditoría", icon: <ClipboardCheck className="w-5 h-5" />, adminOnly: true },
    ],
  },
]

interface SidebarProps {
  activeSection: SectionName
  onSectionChange: (section: SectionName) => void
  llamadasCount?: number
}

export function Sidebar({ activeSection, onSectionChange, llamadasCount = 0 }: SidebarProps) {
  const { user } = useAuth()
  const isAdmin = user?.rol === "admin" || user?.rol === "superadmin"

  return (
    <aside className="w-64 bg-pda-secondary border-r border-pda-border overflow-y-auto p-4 hidden md:block">
      {navSections.map((section) => {
        const visibleItems = section.items.filter(
          (item) => !item.adminOnly || isAdmin
        )
        if (visibleItems.length === 0) return null

        return (
          <div key={section.title} className="mb-6">
            <p className="text-xs font-bold text-pda-muted uppercase tracking-wider mb-2 px-3">
              {section.title}
            </p>
            {visibleItems.map((item) => {
              const isActive = activeSection === item.id
              const badgeCount = item.id === "llamadas" ? llamadasCount : 0

              return (
                <button
                  key={item.id}
                  onClick={() => onSectionChange(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg mb-1 text-base font-semibold transition-all ${
                    isActive
                      ? "bg-pda-accent/10 text-pda-accent font-bold"
                      : "text-pda-text-secondary hover:bg-pda-hover hover:text-white"
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                  {badgeCount > 0 && (
                    <span className="ml-auto px-2 py-0.5 bg-pda-danger rounded-full text-xs font-bold text-white">
                      {badgeCount}
                    </span>
                  )}
                </button>
              )
            })}
          </div>
        )
      })}
    </aside>
  )
}
