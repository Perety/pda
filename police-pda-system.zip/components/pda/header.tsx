"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import type { ThemeColor } from "@/lib/types"
import { Shield, Palette, LogOut } from "lucide-react"

const themes: { name: string; value: ThemeColor; color: string }[] = [
  { name: "Cyan", value: "cyan", color: "#00d9ff" },
  { name: "Azul", value: "blue", color: "#3b82f6" },
  { name: "Verde", value: "green", color: "#10b981" },
  { name: "Púrpura", value: "purple", color: "#8b5cf6" },
  { name: "Rojo", value: "red", color: "#ef4444" },
]

export function Header() {
  const { user, logout, theme, setTheme } = useAuth()
  const [themeOpen, setThemeOpen] = useState(false)

  if (!user) return null

  const initials = user.nombre.substring(0, 2).toUpperCase()
  const serverName = user.servidores?.nombre || "Servidor"

  return (
    <header className="bg-pda-secondary border-b border-pda-border px-6 py-4 flex justify-between items-center sticky top-0 z-50 shadow-md">
      <div className="flex items-center gap-4">
        <div className="w-10 h-10 bg-gradient-to-br from-pda-accent to-[#0088cc] rounded-lg flex items-center justify-center">
          <Shield className="w-5 h-5 text-white" />
        </div>
        <div>
          <h1 className="text-xl font-bold tracking-wide text-white">SISTEMA PDA POLICIAL</h1>
          <p className="text-xs text-pda-muted font-semibold">Centro de Comando</p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <div className="hidden md:flex items-center gap-3 bg-pda-card px-4 py-2 rounded-lg border border-pda-border">
          <div className="w-9 h-9 bg-gradient-to-br from-pda-accent to-[#0088cc] rounded-lg flex items-center justify-center font-bold text-sm text-white">
            {initials}
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">{user.nombre}</h3>
            <p className="text-xs text-pda-muted font-semibold">Placa: {user.placa || "N/A"}</p>
          </div>
        </div>

        <div className="px-3 py-1.5 bg-pda-accent/10 border border-pda-accent rounded-md text-xs font-bold text-pda-accent tracking-wide">
          {serverName}
        </div>

        <div className="relative">
          <button
            onClick={() => setThemeOpen(!themeOpen)}
            className="w-9 h-9 bg-pda-card border border-pda-border rounded-lg flex items-center justify-center text-pda-muted hover:bg-pda-hover hover:text-pda-accent transition-all"
          >
            <Palette className="w-4 h-4" />
          </button>

          {themeOpen && (
            <div className="absolute top-full right-0 mt-2 bg-pda-secondary border border-pda-border rounded-lg p-2 shadow-pda min-w-40 z-50">
              {themes.map((t) => (
                <button
                  key={t.value}
                  onClick={() => {
                    setTheme(t.value)
                    setThemeOpen(false)
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-semibold hover:bg-pda-hover transition-all ${
                    theme === t.value ? "bg-pda-hover text-pda-accent" : "text-white"
                  }`}
                >
                  <div
                    className="w-5 h-5 rounded"
                    style={{ backgroundColor: t.color }}
                  />
                  <span>{t.name}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        <button
          onClick={() => {
            if (confirm("¿Cerrar sesión?")) logout()
          }}
          className="px-4 py-2 bg-transparent border border-pda-border rounded-md text-pda-muted font-bold text-xs uppercase tracking-wide hover:bg-pda-danger hover:border-pda-danger hover:text-white transition-all"
        >
          <LogOut className="w-4 h-4 md:hidden" />
          <span className="hidden md:inline">Salir</span>
        </button>
      </div>
    </header>
  )
}
