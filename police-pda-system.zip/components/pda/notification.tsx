"use client"

import { useEffect, useState } from "react"
import { CheckCircle, AlertCircle, Info, X } from "lucide-react"

export type NotificationType = "success" | "error" | "warning" | "info"

interface NotificationData {
  id: string
  message: string
  type: NotificationType
}

let notificationId = 0
let addNotificationGlobal: ((message: string, type: NotificationType) => void) | null = null

export function showNotification(message: string, type: NotificationType = "info") {
  if (addNotificationGlobal) {
    addNotificationGlobal(message, type)
  }
}

export function NotificationContainer() {
  const [notifications, setNotifications] = useState<NotificationData[]>([])

  useEffect(() => {
    addNotificationGlobal = (message: string, type: NotificationType) => {
      const id = String(++notificationId)
      setNotifications((prev) => [...prev, { id, message, type }])
      setTimeout(() => {
        setNotifications((prev) => prev.filter((n) => n.id !== id))
      }, 4000)
    }

    return () => {
      addNotificationGlobal = null
    }
  }, [])

  const removeNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id))
  }

  const getIcon = (type: NotificationType) => {
    switch (type) {
      case "success":
        return <CheckCircle className="w-5 h-5" />
      case "error":
        return <AlertCircle className="w-5 h-5" />
      case "warning":
        return <AlertCircle className="w-5 h-5" />
      default:
        return <Info className="w-5 h-5" />
    }
  }

  const getBorderColor = (type: NotificationType) => {
    switch (type) {
      case "success":
        return "border-l-pda-success"
      case "error":
        return "border-l-pda-danger"
      case "warning":
        return "border-l-pda-warning"
      default:
        return "border-l-pda-accent"
    }
  }

  return (
    <div className="fixed top-24 right-6 z-[2000] flex flex-col gap-3 max-w-sm">
      {notifications.map((notification) => (
        <div
          key={notification.id}
          className={`bg-pda-secondary border border-pda-border border-l-4 ${getBorderColor(
            notification.type
          )} rounded-lg p-4 shadow-pda animate-in slide-in-from-right duration-300 flex items-start gap-3`}
        >
          <span className={`text-pda-${notification.type === "info" ? "accent" : notification.type}`}>
            {getIcon(notification.type)}
          </span>
          <p className="text-sm font-semibold text-white flex-1">{notification.message}</p>
          <button
            onClick={() => removeNotification(notification.id)}
            className="text-pda-muted hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  )
}
