"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"
import { Modal, ModalActions } from "@/components/pda/modal"
import { showNotification } from "@/components/pda/notification"
import { Section, ListItem, Button, EmptyState, Input, Textarea, Select, FormGrid, FormFullWidth } from "@/components/pda/ui-elements"
import { Megaphone, Eye, Tag, Calendar, CheckCircle, Plus } from "lucide-react"
import type { Bolo } from "@/lib/types"

function formatDate(dateString: string) {
  if (!dateString) return ""
  const date = new Date(dateString)
  return date.toLocaleDateString("es-ES", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })
}

export function BoloSection() {
  const { user, serverId } = useAuth()
  const [bolos, setBolos] = useState<Bolo[]>([])
  const [loading, setLoading] = useState(true)
  const [modalOpen, setModalOpen] = useState(false)
  
  // Form state
  const [titulo, setTitulo] = useState("")
  const [tipo, setTipo] = useState("Persona")
  const [descripcion, setDescripcion] = useState("")

  const loadBolos = async () => {
    if (!serverId) return
    const supabase = createClient()
    const { data } = await supabase
      .from("bolo")
      .select("*")
      .eq("servidor_id", serverId)
      .eq("activo", true)
      .order("created_at", { ascending: false })
    setBolos(data || [])
    setLoading(false)
  }

  useEffect(() => {
    loadBolos()
  }, [serverId])

  const openModal = () => {
    setTitulo("")
    setTipo("Persona")
    setDescripcion("")
    setModalOpen(true)
  }

  const handleSave = async () => {
    if (!titulo.trim() || !descripcion.trim()) {
      showNotification("Datos incompletos", "error")
      return
    }

    const supabase = createClient()
    const data = {
      titulo: titulo.trim(),
      tipo,
      descripcion: descripcion.trim(),
      activo: true,
      servidor_id: serverId,
      creado_por: user?.nombre,
      estado: "activo",
    }

    const { error } = await supabase.from("bolo").insert([data])

    if (error) {
      showNotification("Error: " + error.message, "error")
      return
    }

    await supabase.from("auditoria").insert([{
      usuario_id: user?.id,
      usuario_nombre: user?.nombre,
      servidor_id: serverId,
      accion: "crear",
      modulo: "bolo",
      descripcion: `Título: ${data.titulo}`,
      fecha_hora: new Date().toISOString(),
    }])

    setModalOpen(false)
    loadBolos()
    showNotification("BOLO publicado", "success")
  }

  const handleCerrar = async (id: string) => {
    if (!confirm("¿Marcar como resuelto?")) return
    
    const supabase = createClient()
    await supabase.from("bolo").update({ activo: false, estado: "cerrado" }).eq("id", id)
    
    await supabase.from("auditoria").insert([{
      usuario_id: user?.id,
      usuario_nombre: user?.nombre,
      servidor_id: serverId,
      accion: "cerrar",
      modulo: "bolo",
      descripcion: `ID: ${id}`,
      fecha_hora: new Date().toISOString(),
    }])

    loadBolos()
    showNotification("BOLO cerrado", "success")
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin w-8 h-8 border-4 border-pda-accent border-t-transparent rounded-full" />
      </div>
    )
  }

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-3xl font-bold tracking-wide text-white flex items-center gap-3">
          <Megaphone className="w-7 h-7 text-pda-accent" /> ALERTAS BOLO
        </h2>
        <p className="text-pda-muted font-semibold mt-1">Be On the Look Out - Búsqueda y Captura</p>
      </div>

      <Section
        title="Alertas Activas"
        actions={
          <Button variant="accent" onClick={openModal}>
            <Plus className="w-4 h-4" /> NUEVO BOLO
          </Button>
        }
      >
        {bolos.length > 0 ? (
          <div className="space-y-3">
            {bolos.map((b) => (
              <ListItem
                key={b.id}
                borderColor="warning"
                title={
                  <span className="flex items-center gap-2">
                    <Eye className="w-4 h-4" /> {b.titulo}
                  </span>
                }
                meta={[
                  <span key="tipo" className="flex items-center gap-1.5">
                    <Tag className="w-4 h-4" /> Tipo: {b.tipo}
                  </span>,
                  <span key="fecha" className="flex items-center gap-1.5">
                    <Calendar className="w-4 h-4" /> {formatDate(b.created_at)}
                  </span>,
                ]}
                description={b.descripcion}
                actions={
                  <Button variant="success" onClick={() => handleCerrar(b.id)}>
                    <CheckCircle className="w-4 h-4" /> CAPTURADO
                  </Button>
                }
              />
            ))}
          </div>
        ) : (
          <EmptyState icon={<CheckCircle className="w-12 h-12" />} message="No hay BOLOs activos" />
        )}
      </Section>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="NUEVO BOLO">
        <FormGrid>
          <Input label="Título (Nombre/Matrícula)" value={titulo} onChange={setTitulo} required />
          <Select
            label="Tipo"
            value={tipo}
            onChange={setTipo}
            options={[
              { value: "Persona", label: "Persona" },
              { value: "Vehículo", label: "Vehículo" },
            ]}
          />
          <FormFullWidth>
            <Textarea label="Descripción / Razón" value={descripcion} onChange={setDescripcion} required />
          </FormFullWidth>
        </FormGrid>
        <ModalActions>
          <Button onClick={() => setModalOpen(false)}>CANCELAR</Button>
          <Button variant="accent" onClick={handleSave}>PUBLICAR</Button>
        </ModalActions>
      </Modal>
    </div>
  )
}
