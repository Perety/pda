"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"
import { Modal, ModalActions } from "@/components/pda/modal"
import { showNotification } from "@/components/pda/notification"
import { Section, ListItem, Button, EmptyState, Input, Textarea, FormGrid, FormFullWidth } from "@/components/pda/ui-elements"
import { Phone, MapPin, Clock, Radio, CheckCheck, Plus } from "lucide-react"
import type { Llamada } from "@/lib/types"

function formatDate(dateString: string) {
  if (!dateString) return ""
  const date = new Date(dateString)
  return date.toLocaleDateString("es-ES", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })
}

interface LlamadasSectionProps {
  onCountChange?: (count: number) => void
}

export function LlamadasSection({ onCountChange }: LlamadasSectionProps) {
  const { user, serverId } = useAuth()
  const [llamadas, setLlamadas] = useState<Llamada[]>([])
  const [loading, setLoading] = useState(true)
  const [modalOpen, setModalOpen] = useState(false)
  
  // Form state
  const [tipo, setTipo] = useState("")
  const [ubicacion, setUbicacion] = useState("")
  const [descripcion, setDescripcion] = useState("")

  const loadLlamadas = async () => {
    if (!serverId) return
    const supabase = createClient()
    const { data } = await supabase
      .from("llamadas")
      .select("*")
      .eq("servidor_id", serverId)
      .order("created_at", { ascending: false })
      .limit(20)
    setLlamadas(data || [])
    onCountChange?.(data?.length || 0)
    setLoading(false)
  }

  useEffect(() => {
    loadLlamadas()
  }, [serverId])

  const openModal = () => {
    setTipo("")
    setUbicacion("")
    setDescripcion("")
    setModalOpen(true)
  }

  const handleSave = async () => {
    if (!tipo.trim() || !ubicacion.trim()) {
      showNotification("Datos incompletos", "error")
      return
    }

    const supabase = createClient()
    const data = {
      tipo: tipo.trim(),
      ubicacion: ubicacion.trim(),
      descripcion: descripcion.trim(),
      servidor_id: serverId,
      creado_por: user?.nombre,
      estado: "pendiente",
    }

    const { error } = await supabase.from("llamadas").insert([data])

    if (error) {
      showNotification("Error: " + error.message, "error")
      return
    }

    await supabase.from("auditoria").insert([{
      usuario_id: user?.id,
      usuario_nombre: user?.nombre,
      servidor_id: serverId,
      accion: "crear",
      modulo: "llamadas",
      descripcion: `Ubicación: ${data.ubicacion}`,
      fecha_hora: new Date().toISOString(),
    }])

    setModalOpen(false)
    loadLlamadas()
    showNotification("Unidades alertadas", "warning")
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin w-8 h-8 border-4 border-pda-accent border-t-transparent rounded-full" />
      </div>
    )
  }

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-3xl font-bold tracking-wide text-white flex items-center gap-3">
          <Phone className="w-7 h-7 text-pda-accent" /> CENTRAL 911
        </h2>
        <p className="text-pda-muted font-semibold mt-1">Despacho de emergencias</p>
      </div>

      <Section
        title="Llamadas Activas"
        actions={
          <Button variant="accent" onClick={openModal}>
            <Radio className="w-4 h-4" /> NUEVA LLAMADA
          </Button>
        }
      >
        {llamadas.length > 0 ? (
          <div className="space-y-3">
            {llamadas.map((l) => (
              <ListItem
                key={l.id}
                borderColor="danger"
                title={
                  <span className="flex items-center gap-2">
                    <Phone className="w-4 h-4" /> {l.tipo}
                  </span>
                }
                meta={[
                  <span key="ubicacion" className="flex items-center gap-1.5">
                    <MapPin className="w-4 h-4" /> {l.ubicacion}
                  </span>,
                  <span key="fecha" className="flex items-center gap-1.5">
                    <Clock className="w-4 h-4" /> {formatDate(l.created_at)}
                  </span>,
                ]}
                description={l.descripcion || undefined}
              />
            ))}
          </div>
        ) : (
          <EmptyState icon={<CheckCheck className="w-12 h-12" />} message="Sin emergencias activas" />
        )}
      </Section>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="DESPACHAR 911">
        <FormGrid>
          <Input label="Tipo de Emergencia" value={tipo} onChange={setTipo} placeholder="Ej: Robo en progreso" required />
          <Input label="Ubicación" value={ubicacion} onChange={setUbicacion} required />
          <FormFullWidth>
            <Textarea label="Detalles" value={descripcion} onChange={setDescripcion} />
          </FormFullWidth>
        </FormGrid>
        <ModalActions>
          <Button onClick={() => setModalOpen(false)}>CANCELAR</Button>
          <Button variant="danger" onClick={handleSave}>ENVIAR ALERTA</Button>
        </ModalActions>
      </Modal>
    </div>
  )
}
