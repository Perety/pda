"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"
import { Modal, ModalActions } from "@/components/pda/modal"
import { showNotification } from "@/components/pda/notification"
import { Section, ListItem, Button, EmptyState, SearchInput, Input, Textarea, FormGrid, FormFullWidth } from "@/components/pda/ui-elements"
import { FileText, User, DollarSign, UserCheck, Calendar, Trash2, Plus, FileCheck } from "lucide-react"
import type { Multa } from "@/lib/types"

function formatDate(dateString: string) {
  if (!dateString) return ""
  const date = new Date(dateString)
  return date.toLocaleDateString("es-ES", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })
}

export function MultasSection() {
  const { user, serverId } = useAuth()
  const [multas, setMultas] = useState<Multa[]>([])
  const [search, setSearch] = useState("")
  const [loading, setLoading] = useState(true)
  const [modalOpen, setModalOpen] = useState(false)
  
  // Form state
  const [ciudadano, setCiudadano] = useState("")
  const [importe, setImporte] = useState("")
  const [motivo, setMotivo] = useState("")

  const isAdmin = user?.rol === "admin" || user?.rol === "superadmin"

  const loadMultas = async () => {
    if (!serverId) return
    const supabase = createClient()
    const { data } = await supabase
      .from("multas")
      .select("*")
      .eq("servidor_id", serverId)
      .order("created_at", { ascending: false })
    setMultas(data || [])
    setLoading(false)
  }

  useEffect(() => {
    loadMultas()
  }, [serverId])

  const filtered = multas.filter(
    (m) =>
      m.ciudadano_nombre?.toLowerCase().includes(search.toLowerCase()) ||
      m.motivo?.toLowerCase().includes(search.toLowerCase())
  )

  const openModal = () => {
    setCiudadano("")
    setImporte("")
    setMotivo("")
    setModalOpen(true)
  }

  const handleSave = async () => {
    const importeNum = parseFloat(importe)
    if (!ciudadano.trim() || isNaN(importeNum) || !motivo.trim()) {
      showNotification("Datos incompletos", "error")
      return
    }

    const supabase = createClient()
    const data = {
      ciudadano_nombre: ciudadano.trim(),
      importe: importeNum,
      motivo: motivo.trim(),
      oficial_nombre: user?.nombre,
      oficial_id: user?.id,
      servidor_id: serverId,
      estado: "pendiente",
    }

    const { error } = await supabase.from("multas").insert([data])

    if (error) {
      showNotification("Error: " + error.message, "error")
      return
    }

    await supabase.from("auditoria").insert([{
      usuario_id: user?.id,
      usuario_nombre: user?.nombre,
      servidor_id: serverId,
      accion: "crear",
      modulo: "multas",
      descripcion: `Ciudadano: ${data.ciudadano_nombre}, Importe: $${data.importe}`,
      fecha_hora: new Date().toISOString(),
    }])

    setModalOpen(false)
    loadMultas()
    showNotification("Multa creada", "success")
  }

  const handleDelete = async (id: string) => {
    if (!confirm("¿Borrar esta multa?")) return
    
    const supabase = createClient()
    await supabase.from("multas").delete().eq("id", id)
    
    await supabase.from("auditoria").insert([{
      usuario_id: user?.id,
      usuario_nombre: user?.nombre,
      servidor_id: serverId,
      accion: "eliminar",
      modulo: "multas",
      descripcion: `ID: ${id}`,
      fecha_hora: new Date().toISOString(),
    }])

    loadMultas()
    showNotification("Eliminado", "success")
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin w-8 h-8 border-4 border-pda-accent border-t-transparent rounded-full" />
      </div>
    )
  }

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-3xl font-bold tracking-wide text-white flex items-center gap-3">
          <FileText className="w-7 h-7 text-pda-accent" /> REGISTRO DE MULTAS
        </h2>
        <p className="text-pda-muted font-semibold mt-1">Gestión de infracciones y sanciones</p>
      </div>

      <Section
        actions={
          <div className="flex gap-3 flex-wrap">
            <SearchInput value={search} onChange={setSearch} placeholder="Buscar por ciudadano o motivo..." />
            <Button variant="accent" onClick={openModal}>
              <Plus className="w-4 h-4" /> NUEVA MULTA
            </Button>
          </div>
        }
      >
        {filtered.length > 0 ? (
          <div className="space-y-3">
            {filtered.map((m) => (
              <ListItem
                key={m.id}
                title={
                  <span className="flex items-center gap-2">
                    <User className="w-4 h-4" /> {m.ciudadano_nombre}
                  </span>
                }
                meta={[
                  <span key="importe" className="flex items-center gap-1.5">
                    <DollarSign className="w-4 h-4" /> Importe: ${m.importe}
                  </span>,
                  <span key="oficial" className="flex items-center gap-1.5">
                    <UserCheck className="w-4 h-4" /> Oficial: {m.oficial_nombre}
                  </span>,
                  <span key="fecha" className="flex items-center gap-1.5">
                    <Calendar className="w-4 h-4" /> {formatDate(m.created_at)}
                  </span>,
                ]}
                description={`Motivo: ${m.motivo}`}
                actions={
                  isAdmin && (
                    <Button variant="danger" onClick={() => handleDelete(m.id)}>
                      <Trash2 className="w-4 h-4" /> ELIMINAR
                    </Button>
                  )
                }
              />
            ))}
          </div>
        ) : (
          <EmptyState icon={<FileCheck className="w-12 h-12" />} message="No hay multas registradas" />
        )}
      </Section>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="NUEVA MULTA">
        <FormGrid>
          <Input label="Ciudadano" value={ciudadano} onChange={setCiudadano} placeholder="Nombre completo" required />
          <Input label="Importe Total ($)" value={importe} onChange={setImporte} type="number" required />
          <FormFullWidth>
            <Textarea label="Artículos/Motivos" value={motivo} onChange={setMotivo} placeholder="Lista de infracciones..." required />
          </FormFullWidth>
        </FormGrid>
        <ModalActions>
          <Button onClick={() => setModalOpen(false)}>CANCELAR</Button>
          <Button variant="accent" onClick={handleSave}>CREAR MULTA</Button>
        </ModalActions>
      </Modal>
    </div>
  )
}
