"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"
import { Modal, ModalActions } from "@/components/pda/modal"
import { showNotification } from "@/components/pda/notification"
import { Section, ListItem, Button, EmptyState, SearchInput, Input, Textarea, FormGrid, FormFullWidth } from "@/components/pda/ui-elements"
import { Users, User, Award as IdCard, Phone, Pencil, Trash2, Plus } from "lucide-react"
import type { Ciudadano } from "@/lib/types"

export function CiudadanosSection() {
  const { user, serverId } = useAuth()
  const [ciudadanos, setCiudadanos] = useState<Ciudadano[]>([])
  const [search, setSearch] = useState("")
  const [loading, setLoading] = useState(true)
  const [modalOpen, setModalOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  
  // Form state
  const [nombre, setNombre] = useState("")
  const [dni, setDni] = useState("")
  const [telefono, setTelefono] = useState("")
  const [direccion, setDireccion] = useState("")
  const [notas, setNotas] = useState("")

  const isAdmin = user?.rol === "admin" || user?.rol === "superadmin"

  const loadCiudadanos = async () => {
    if (!serverId) return
    const supabase = createClient()
    const { data } = await supabase
      .from("ciudadanos")
      .select("*")
      .eq("servidor_id", serverId)
      .order("created_at", { ascending: false })
    setCiudadanos(data || [])
    setLoading(false)
  }

  useEffect(() => {
    loadCiudadanos()
  }, [serverId])

  const filtered = ciudadanos.filter(
    (c) =>
      c.nombre.toLowerCase().includes(search.toLowerCase()) ||
      c.dni.toLowerCase().includes(search.toLowerCase())
  )

  const openModal = async (id?: string) => {
    if (id) {
      const supabase = createClient()
      const { data } = await supabase.from("ciudadanos").select("*").eq("id", id).single()
      if (data) {
        setEditingId(id)
        setNombre(data.nombre)
        setDni(data.dni)
        setTelefono(data.telefono || "")
        setDireccion(data.direccion || "")
        setNotas(data.notas || "")
      }
    } else {
      setEditingId(null)
      setNombre("")
      setDni("")
      setTelefono("")
      setDireccion("")
      setNotas("")
    }
    setModalOpen(true)
  }

  const handleSave = async () => {
    if (!nombre.trim() || !dni.trim()) {
      showNotification("Faltan datos obligatorios", "error")
      return
    }

    const supabase = createClient()
    const data = {
      nombre: nombre.trim(),
      dni: dni.trim(),
      telefono: telefono.trim(),
      direccion: direccion.trim(),
      notas: notas.trim(),
      servidor_id: serverId,
      oficial_registro: user?.nombre,
    }

    let result
    if (editingId) {
      result = await supabase.from("ciudadanos").update(data).eq("id", editingId)
    } else {
      result = await supabase.from("ciudadanos").insert([data])
    }

    if (result.error) {
      showNotification("Error al guardar: " + result.error.message, "error")
      return
    }

    // Audit
    await supabase.from("auditoria").insert([{
      usuario_id: user?.id,
      usuario_nombre: user?.nombre,
      servidor_id: serverId,
      accion: editingId ? "editar" : "crear",
      modulo: "ciudadanos",
      descripcion: `Nombre: ${data.nombre}, DNI: ${data.dni}`,
      fecha_hora: new Date().toISOString(),
    }])

    setModalOpen(false)
    loadCiudadanos()
    showNotification("Guardado correctamente", "success")
  }

  const handleDelete = async (id: string, nombre: string) => {
    if (!confirm(`¿Eliminar a ${nombre}?`)) return
    
    const supabase = createClient()
    await supabase.from("ciudadanos").delete().eq("id", id)
    
    await supabase.from("auditoria").insert([{
      usuario_id: user?.id,
      usuario_nombre: user?.nombre,
      servidor_id: serverId,
      accion: "eliminar",
      modulo: "ciudadanos",
      descripcion: `Nombre: ${nombre}`,
      fecha_hora: new Date().toISOString(),
    }])

    loadCiudadanos()
    showNotification("Eliminado", "success")
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin w-8 h-8 border-4 border-pda-accent border-t-transparent rounded-full" />
      </div>
    )
  }

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-3xl font-bold tracking-wide text-white flex items-center gap-3">
          <Users className="w-7 h-7 text-pda-accent" /> BASE DE DATOS DE CIUDADANOS
        </h2>
        <p className="text-pda-muted font-semibold mt-1">Gestión de fichas ciudadanas</p>
      </div>

      <Section
        actions={
          <div className="flex gap-3 flex-wrap">
            <SearchInput value={search} onChange={setSearch} placeholder="Buscar por nombre o DNI..." />
            <Button variant="accent" onClick={() => openModal()}>
              <Plus className="w-4 h-4" /> NUEVO
            </Button>
          </div>
        }
      >
        {filtered.length > 0 ? (
          <div className="space-y-3">
            {filtered.map((c) => (
              <ListItem
                key={c.id}
                title={
                  <span className="flex items-center gap-2">
                    <User className="w-4 h-4" /> {c.nombre}
                  </span>
                }
                meta={[
                  <span key="dni" className="flex items-center gap-1.5">
                    <IdCard className="w-4 h-4" /> DNI: {c.dni}
                  </span>,
                  c.telefono && (
                    <span key="tel" className="flex items-center gap-1.5">
                      <Phone className="w-4 h-4" /> {c.telefono}
                    </span>
                  ),
                ].filter(Boolean)}
                description={c.notas || undefined}
                actions={
                  <>
                    <Button onClick={() => openModal(c.id)}>
                      <Pencil className="w-4 h-4" /> EDITAR
                    </Button>
                    {isAdmin && (
                      <Button variant="danger" onClick={() => handleDelete(c.id, c.nombre)}>
                        <Trash2 className="w-4 h-4" /> ELIMINAR
                      </Button>
                    )}
                  </>
                }
              />
            ))}
          </div>
        ) : (
          <EmptyState icon={<Users className="w-12 h-12" />} message="No se encontraron ciudadanos" />
        )}
      </Section>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editingId ? "EDITAR CIUDADANO" : "NUEVO CIUDADANO"}>
        <FormGrid>
          <Input label="Nombre Completo" value={nombre} onChange={setNombre} required />
          <Input label="DNI" value={dni} onChange={setDni} required />
          <Input label="Teléfono" value={telefono} onChange={setTelefono} />
          <Input label="Dirección" value={direccion} onChange={setDireccion} />
          <FormFullWidth>
            <Textarea label="Notas" value={notas} onChange={setNotas} />
          </FormFullWidth>
        </FormGrid>
        <ModalActions>
          <Button onClick={() => setModalOpen(false)}>CANCELAR</Button>
          <Button variant="accent" onClick={handleSave}>GUARDAR</Button>
        </ModalActions>
      </Modal>
    </div>
  )
}
