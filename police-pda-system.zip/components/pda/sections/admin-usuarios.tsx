"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"
import { Modal, ModalActions } from "@/components/pda/modal"
import { showNotification } from "@/components/pda/notification"
import { Section, ListItem, Button, EmptyState, Input, Select, FormGrid } from "@/components/pda/ui-elements"
import { UserCog, Plus, Trash2, Power, Lock } from "lucide-react"
import type { Usuario } from "@/lib/types"

export function AdminUsuariosSection() {
  const { user, serverId } = useAuth()
  const [usuarios, setUsuarios] = useState<Usuario[]>([])
  const [loading, setLoading] = useState(true)
  const [modalOpen, setModalOpen] = useState(false)
  
  // Form state
  const [nombre, setNombre] = useState("")
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [rol, setRol] = useState("oficial")

  const isAdmin = user?.rol === "admin" || user?.rol === "superadmin"

  const loadUsuarios = async () => {
    if (!serverId) return
    const supabase = createClient()
    const { data } = await supabase
      .from("usuarios")
      .select("*")
      .eq("servidor_id", serverId)
    setUsuarios((data || []) as Usuario[])
    setLoading(false)
  }

  useEffect(() => {
    if (isAdmin) loadUsuarios()
    else setLoading(false)
  }, [serverId, isAdmin])

  const openModal = () => {
    setNombre("")
    setUsername("")
    setPassword("")
    setRol("oficial")
    setModalOpen(true)
  }

  const handleSave = async () => {
    if (!nombre.trim() || !username.trim() || !password.trim()) {
      showNotification("Completa todos los campos", "error")
      return
    }

    const supabase = createClient()
    const data = {
      nombre: nombre.trim(),
      username: username.trim(),
      password: password.trim(),
      rol,
      servidor_id: serverId,
      activo: true,
    }

    const { error } = await supabase.from("usuarios").insert([data])

    if (error) {
      showNotification("Error: " + error.message, "error")
      return
    }

    setModalOpen(false)
    loadUsuarios()
    showNotification("Usuario creado", "success")
  }

  const handleDelete = async (id: string, nombre: string) => {
    if (!confirm(`¿Borrar a ${nombre}?`)) return
    
    const supabase = createClient()
    await supabase.from("usuarios").delete().eq("id", id)
    loadUsuarios()
    showNotification("Usuario eliminado", "success")
  }

  const toggleActivo = async (id: string, estadoActual: boolean) => {
    const supabase = createClient()
    await supabase.from("usuarios").update({ activo: !estadoActual }).eq("id", id)
    loadUsuarios()
    showNotification(estadoActual ? "Usuario desactivado" : "Usuario activado", "info")
  }

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-pda-muted">
        <Lock className="w-16 h-16 mb-4 opacity-50" />
        <p className="text-lg font-semibold">Acceso denegado - Solo administradores</p>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin w-8 h-8 border-4 border-pda-accent border-t-transparent rounded-full" />
      </div>
    )
  }

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-3xl font-bold tracking-wide text-white flex items-center gap-3">
          <UserCog className="w-7 h-7 text-pda-accent" /> GESTIÓN DE USUARIOS
        </h2>
        <p className="text-pda-muted font-semibold mt-1">Administrar usuarios del servidor</p>
      </div>

      <Section
        title="Usuarios"
        actions={
          <Button variant="accent" onClick={openModal}>
            <Plus className="w-4 h-4" /> NUEVO
          </Button>
        }
      >
        {usuarios.length > 0 ? (
          <div className="space-y-3">
            {usuarios.map((u) => (
              <ListItem
                key={u.id}
                title={`${u.nombre} (${u.rol})`}
                meta={[
                  <span key="user">Usuario: {u.username} | Estado: {u.activo ? "Activo" : "Inactivo"}</span>,
                ]}
                tag={{ label: u.activo ? "ACTIVO" : "INACTIVO", color: u.activo ? "success" : "danger" }}
                actions={
                  <>
                    <Button
                      variant={u.activo ? "warning" : "success"}
                      onClick={() => toggleActivo(u.id, u.activo)}
                    >
                      <Power className="w-4 h-4" /> {u.activo ? "DESACTIVAR" : "ACTIVAR"}
                    </Button>
                    <Button variant="danger" onClick={() => handleDelete(u.id, u.nombre)}>
                      <Trash2 className="w-4 h-4" /> ELIMINAR
                    </Button>
                  </>
                }
              />
            ))}
          </div>
        ) : (
          <EmptyState icon={<UserCog className="w-12 h-12" />} message="No hay usuarios" />
        )}
      </Section>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="CREAR USUARIO">
        <FormGrid>
          <Input label="Nombre" value={nombre} onChange={setNombre} required />
          <Input label="Usuario" value={username} onChange={setUsername} required />
          <Input label="Contraseña" value={password} onChange={setPassword} type="password" required />
          <Select
            label="Rol"
            value={rol}
            onChange={setRol}
            options={[
              { value: "oficial", label: "Oficial" },
              { value: "admin", label: "Admin" },
            ]}
          />
        </FormGrid>
        <ModalActions>
          <Button onClick={() => setModalOpen(false)}>CANCELAR</Button>
          <Button variant="accent" onClick={handleSave}>CREAR</Button>
        </ModalActions>
      </Modal>
    </div>
  )
}
