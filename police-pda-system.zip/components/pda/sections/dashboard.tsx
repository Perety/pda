"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"
import { StatCard, Section, ListItem, EmptyState, Tag } from "@/components/pda/ui-elements"
import { Users, FileText, HandMetal, Megaphone, Clock, UserCheck } from "lucide-react"
import type { Servicio } from "@/lib/types"

interface DashboardStats {
  ciudadanos: number
  multas: number
  arrestos: number
  bolo: number
}

export function DashboardSection() {
  const { serverId } = useAuth()
  const [stats, setStats] = useState<DashboardStats>({ ciudadanos: 0, multas: 0, arrestos: 0, bolo: 0 })
  const [activeOfficers, setActiveOfficers] = useState<Servicio[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!serverId) return

    async function loadData() {
      const supabase = createClient()

      const [ciudadanosRes, multasRes, arrestosRes, boloRes, oficersRes] = await Promise.all([
        supabase.from("ciudadanos").select("*", { count: "exact", head: true }).eq("servidor_id", serverId),
        supabase.from("multas").select("*", { count: "exact", head: true }).eq("servidor_id", serverId),
        supabase.from("arrestos").select("*", { count: "exact", head: true }).eq("servidor_id", serverId),
        supabase.from("bolo").select("*", { count: "exact", head: true }).eq("servidor_id", serverId).eq("activo", true),
        supabase.from("servicio").select("*, usuarios(nombre, placa, rango)").eq("servidor_id", serverId).is("hora_fin", null),
      ])

      setStats({
        ciudadanos: ciudadanosRes.count || 0,
        multas: multasRes.count || 0,
        arrestos: arrestosRes.count || 0,
        bolo: boloRes.count || 0,
      })

      setActiveOfficers((oficersRes.data || []) as Servicio[])
      setLoading(false)
    }

    loadData()
  }, [serverId])

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin w-8 h-8 border-4 border-pda-accent border-t-transparent rounded-full" />
      </div>
    )
  }

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-3xl font-bold tracking-wide text-white flex items-center gap-3">
          <Clock className="w-7 h-7 text-pda-accent" /> PANEL DE CONTROL
        </h2>
        <p className="text-pda-muted font-semibold mt-1">Resumen general y estado de la fuerza</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatCard title="Ciudadanos" value={stats.ciudadanos} icon={<Users className="w-5 h-5" />} />
            <StatCard title="Multas" value={stats.multas} icon={<FileText className="w-5 h-5" />} />
            <StatCard title="Arrestos" value={stats.arrestos} icon={<HandMetal className="w-5 h-5" />} />
            <StatCard title="Alertas BOLO" value={stats.bolo} icon={<Megaphone className="w-5 h-5" />} color="warning" />
          </div>

          <Section title="Actividad Reciente">
            <EmptyState icon={<Clock className="w-12 h-12" />} message="Funcionalidad en desarrollo" />
          </Section>
        </div>

        <div>
          <Section title="Oficiales en Servicio">
            {activeOfficers.length > 0 ? (
              <div className="space-y-3">
                {activeOfficers.map((s) => {
                  const statusColor = s.estado === "ocupado" ? "danger" : s.estado === "descanso" ? "warning" : "success"
                  return (
                    <ListItem
                      key={s.id}
                      title={
                        <span className="flex items-center gap-2">
                          <UserCheck className="w-4 h-4" />
                          {s.usuarios?.rango} {s.usuarios?.nombre}
                        </span>
                      }
                      meta={[<span key="placa">Placa: {s.usuarios?.placa}</span>]}
                      tag={{ label: s.estado.toUpperCase(), color: statusColor }}
                    />
                  )
                })}
              </div>
            ) : (
              <EmptyState icon={<UserCheck className="w-12 h-12" />} message="No hay oficiales disponibles" />
            )}
          </Section>
        </div>
      </div>
    </div>
  )
}
