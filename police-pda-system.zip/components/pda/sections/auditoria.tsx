"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"
import { Section, ListItem, EmptyState } from "@/components/pda/ui-elements"
import { ClipboardCheck, History, User, Clock, Lock } from "lucide-react"
import type { Auditoria } from "@/lib/types"

function formatDate(dateString: string) {
  if (!dateString) return ""
  const date = new Date(dateString)
  return date.toLocaleDateString("es-ES", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })
}

export function AuditoriaSection() {
  const { user, serverId } = useAuth()
  const [auditoria, setAuditoria] = useState<Auditoria[]>([])
  const [loading, setLoading] = useState(true)

  const isAdmin = user?.rol === "admin" || user?.rol === "superadmin"

  useEffect(() => {
    if (!serverId || !isAdmin) {
      setLoading(false)
      return
    }

    async function loadAuditoria() {
      const supabase = createClient()
      const { data } = await supabase
        .from("auditoria")
        .select("*")
        .eq("servidor_id", serverId)
        .order("fecha_hora", { ascending: false })
        .limit(50)
      setAuditoria((data || []) as Auditoria[])
      setLoading(false)
    }

    loadAuditoria()
  }, [serverId, isAdmin])

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-pda-muted">
        <Lock className="w-16 h-16 mb-4 opacity-50" />
        <p className="text-lg font-semibold">Acceso denegado - Solo administradores</p>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin w-8 h-8 border-4 border-pda-accent border-t-transparent rounded-full" />
      </div>
    )
  }

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-3xl font-bold tracking-wide text-white flex items-center gap-3">
          <ClipboardCheck className="w-7 h-7 text-pda-accent" /> REGISTRO DE AUDITORÍA
        </h2>
        <p className="text-pda-muted font-semibold mt-1">Historial de acciones del servidor</p>
      </div>

      <Section>
        {auditoria.length > 0 ? (
          <div className="space-y-3">
            {auditoria.map((a) => (
              <ListItem
                key={a.id}
                title={
                  <span className="flex items-center gap-2">
                    <History className="w-4 h-4" /> {a.accion.toUpperCase()}
                  </span>
                }
                meta={[
                  <span key="fecha" className="flex items-center gap-1.5">
                    <Clock className="w-4 h-4" /> {formatDate(a.fecha_hora)}
                  </span>,
                  <span key="usuario" className="flex items-center gap-1.5">
                    <User className="w-4 h-4" /> {a.usuario_nombre || "Sistema"}
                  </span>,
                ]}
                description={a.descripcion || a.detalles || undefined}
              />
            ))}
          </div>
        ) : (
          <EmptyState icon={<ClipboardCheck className="w-12 h-12" />} message="Registro vacío" />
        )}
      </Section>
    </div>
  )
}
