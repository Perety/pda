"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"
import { Modal, ModalActions } from "@/components/pda/modal"
import { showNotification } from "@/components/pda/notification"
import { Section, ListItem, Button, EmptyState, SearchInput, Input, Textarea, FormGrid, FormFullWidth } from "@/components/pda/ui-elements"
import { ClipboardList, FileText, UserX, Calendar, FolderOpen, Plus } from "lucide-react"
import type { Denuncia } from "@/lib/types"

function formatDate(dateString: string) {
  if (!dateString) return ""
  const date = new Date(dateString)
  return date.toLocaleDateString("es-ES", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })
}

export function DenunciasSection() {
  const { user, serverId } = useAuth()
  const [denuncias, setDenuncias] = useState<Denuncia[]>([])
  const [search, setSearch] = useState("")
  const [loading, setLoading] = useState(true)
  const [modalOpen, setModalOpen] = useState(false)
  
  // Form state
  const [victima, setVictima] = useState("")
  const [acusado, setAcusado] = useState("")
  const [narracion, setNarracion] = useState("")

  const loadDenuncias = async () => {
    if (!serverId) return
    const supabase = createClient()
    const { data } = await supabase
      .from("denuncias")
      .select("*")
      .eq("servidor_id", serverId)
      .order("created_at", { ascending: false })
    setDenuncias(data || [])
    setLoading(false)
  }

  useEffect(() => {
    loadDenuncias()
  }, [serverId])

  const filtered = denuncias.filter(
    (d) =>
      d.victima.toLowerCase().includes(search.toLowerCase()) ||
      d.acusado?.toLowerCase().includes(search.toLowerCase())
  )

  const openModal = () => {
    setVictima("")
    setAcusado("")
    setNarracion("")
    setModalOpen(true)
  }

  const handleSave = async () => {
    if (!victima.trim() || !narracion.trim()) {
      showNotification("Faltan datos", "error")
      return
    }

    const supabase = createClient()
    const data = {
      victima: victima.trim(),
      acusado: acusado.trim(),
      narracion: narracion.trim(),
      servidor_id: serverId,
      oficial_receptor: user?.nombre,
    }

    const { error } = await supabase.from("denuncias").insert([data])

    if (error) {
      showNotification("Error: " + error.message, "error")
      return
    }

    await supabase.from("auditoria").insert([{
      usuario_id: user?.id,
      usuario_nombre: user?.nombre,
      servidor_id: serverId,
      accion: "crear",
      modulo: "denuncias",
      descripcion: `Víctima: ${data.victima}`,
      fecha_hora: new Date().toISOString(),
    }])

    setModalOpen(false)
    loadDenuncias()
    showNotification("Denuncia archivada", "success")
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin w-8 h-8 border-4 border-pda-accent border-t-transparent rounded-full" />
      </div>
    )
  }

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-3xl font-bold tracking-wide text-white flex items-center gap-3">
          <ClipboardList className="w-7 h-7 text-pda-accent" /> REGISTRO DE DENUNCIAS
        </h2>
        <p className="text-pda-muted font-semibold mt-1">Reportes civiles</p>
      </div>

      <Section
        actions={
          <div className="flex gap-3 flex-wrap">
            <SearchInput value={search} onChange={setSearch} placeholder="Buscar denuncia..." />
            <Button variant="accent" onClick={openModal}>
              <Plus className="w-4 h-4" /> NUEVA DENUNCIA
            </Button>
          </div>
        }
      >
        {filtered.length > 0 ? (
          <div className="space-y-3">
            {filtered.map((d) => (
              <ListItem
                key={d.id}
                title={
                  <span className="flex items-center gap-2">
                    <FileText className="w-4 h-4" /> Víctima: {d.victima}
                  </span>
                }
                meta={[
                  <span key="acusado" className="flex items-center gap-1.5">
                    <UserX className="w-4 h-4" /> Acusado: {d.acusado || "Desconocido"}
                  </span>,
                  <span key="fecha" className="flex items-center gap-1.5">
                    <Calendar className="w-4 h-4" /> {formatDate(d.created_at)}
                  </span>,
                ]}
                description={d.narracion}
              />
            ))}
          </div>
        ) : (
          <EmptyState icon={<FolderOpen className="w-12 h-12" />} message="No hay denuncias" />
        )}
      </Section>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="NUEVA DENUNCIA">
        <FormGrid>
          <Input label="Víctima/Denunciante" value={victima} onChange={setVictima} required />
          <Input label="Acusado" value={acusado} onChange={setAcusado} placeholder="Si se conoce" />
          <FormFullWidth>
            <Textarea label="Narración de los hechos" value={narracion} onChange={setNarracion} required />
          </FormFullWidth>
        </FormGrid>
        <ModalActions>
          <Button onClick={() => setModalOpen(false)}>CANCELAR</Button>
          <Button variant="accent" onClick={handleSave}>REGISTRAR</Button>
        </ModalActions>
      </Modal>
    </div>
  )
}
