"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"
import { Modal, ModalActions } from "@/components/pda/modal"
import { showNotification } from "@/components/pda/notification"
import { Section, ListItem, Button, EmptyState, Input, Textarea, FormGrid, FormFullWidth } from "@/components/pda/ui-elements"
import { Search, Folder, UserCog, Plus } from "lucide-react"
import type { Investigacion } from "@/lib/types"

export function InvestigacionesSection() {
  const { user, serverId } = useAuth()
  const [investigaciones, setInvestigaciones] = useState<Investigacion[]>([])
  const [loading, setLoading] = useState(true)
  const [modalOpen, setModalOpen] = useState(false)
  
  // Form state
  const [titulo, setTitulo] = useState("")
  const [descripcion, setDescripcion] = useState("")

  const loadInvestigaciones = async () => {
    if (!serverId) return
    const supabase = createClient()
    const { data } = await supabase
      .from("investigaciones")
      .select("*")
      .eq("servidor_id", serverId)
      .order("created_at", { ascending: false })
    setInvestigaciones(data || [])
    setLoading(false)
  }

  useEffect(() => {
    loadInvestigaciones()
  }, [serverId])

  const openModal = () => {
    setTitulo("")
    setDescripcion("")
    setModalOpen(true)
  }

  const handleSave = async () => {
    if (!titulo.trim()) {
      showNotification("Faltan datos", "error")
      return
    }

    const supabase = createClient()
    const data = {
      titulo: titulo.trim(),
      descripcion: descripcion.trim(),
      estado: "activa",
      servidor_id: serverId,
      detective_lider: user?.nombre,
      investigador_id: user?.id,
    }

    const { error } = await supabase.from("investigaciones").insert([data])

    if (error) {
      showNotification("Error: " + error.message, "error")
      return
    }

    await supabase.from("auditoria").insert([{
      usuario_id: user?.id,
      usuario_nombre: user?.nombre,
      servidor_id: serverId,
      accion: "crear",
      modulo: "investigaciones",
      descripcion: `Título: ${data.titulo}`,
      fecha_hora: new Date().toISOString(),
    }])

    setModalOpen(false)
    loadInvestigaciones()
    showNotification("Caso abierto", "success")
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin w-8 h-8 border-4 border-pda-accent border-t-transparent rounded-full" />
      </div>
    )
  }

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-3xl font-bold tracking-wide text-white flex items-center gap-3">
          <Search className="w-7 h-7 text-pda-accent" /> CASOS DE INVESTIGACIÓN
        </h2>
        <p className="text-pda-muted font-semibold mt-1">Expedientes activos</p>
      </div>

      <Section
        title="Expedientes"
        actions={
          <Button variant="accent" onClick={openModal}>
            <Plus className="w-4 h-4" /> ABRIR CASO
          </Button>
        }
      >
        {investigaciones.length > 0 ? (
          <div className="space-y-3">
            {investigaciones.map((i) => (
              <ListItem
                key={i.id}
                title={
                  <span className="flex items-center gap-2">
                    <Folder className="w-4 h-4" /> {i.titulo}
                  </span>
                }
                meta={[
                  <span key="estado" className="flex items-center gap-1.5">
                    <UserCog className="w-4 h-4" /> Estado: {i.estado}
                  </span>,
                ]}
                description={i.descripcion}
              />
            ))}
          </div>
        ) : (
          <EmptyState icon={<Search className="w-12 h-12" />} message="Sin investigaciones" />
        )}
      </Section>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="NUEVO CASO">
        <FormGrid cols={1}>
          <Input label="Título del Caso" value={titulo} onChange={setTitulo} required />
          <Textarea label="Detalles" value={descripcion} onChange={setDescripcion} required />
        </FormGrid>
        <ModalActions>
          <Button onClick={() => setModalOpen(false)}>CANCELAR</Button>
          <Button variant="accent" onClick={handleSave}>ABRIR CASO</Button>
        </ModalActions>
      </Modal>
    </div>
  )
}
