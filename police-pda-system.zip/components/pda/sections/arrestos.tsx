"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"
import { Modal, ModalActions } from "@/components/pda/modal"
import { showNotification } from "@/components/pda/notification"
import { Section, ListItem, Button, EmptyState, SearchInput, Input, Textarea, FormGrid, FormFullWidth } from "@/components/pda/ui-elements"
import { HandMetal, UserX, Clock, UserCheck, Calendar, Plus, LockOpen } from "lucide-react"
import type { Arresto } from "@/lib/types"

function formatDate(dateString: string) {
  if (!dateString) return ""
  const date = new Date(dateString)
  return date.toLocaleDateString("es-ES", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })
}

export function ArrestosSection() {
  const { user, serverId } = useAuth()
  const [arrestos, setArrestos] = useState<Arresto[]>([])
  const [search, setSearch] = useState("")
  const [loading, setLoading] = useState(true)
  const [modalOpen, setModalOpen] = useState(false)
  
  // Form state
  const [ciudadano, setCiudadano] = useState("")
  const [tiempo, setTiempo] = useState("")
  const [fianza, setFianza] = useState("0")
  const [cargos, setCargos] = useState("")

  const loadArrestos = async () => {
    if (!serverId) return
    const supabase = createClient()
    const { data } = await supabase
      .from("arrestos")
      .select("*")
      .eq("servidor_id", serverId)
      .order("created_at", { ascending: false })
    setArrestos(data || [])
    setLoading(false)
  }

  useEffect(() => {
    loadArrestos()
  }, [serverId])

  const filtered = arrestos.filter((a) =>
    a.ciudadano_nombre?.toLowerCase().includes(search.toLowerCase())
  )

  const openModal = () => {
    setCiudadano("")
    setTiempo("")
    setFianza("0")
    setCargos("")
    setModalOpen(true)
  }

  const handleSave = async () => {
    const tiempoNum = parseInt(tiempo)
    const fianzaNum = parseFloat(fianza) || 0
    
    if (!ciudadano.trim() || isNaN(tiempoNum) || !cargos.trim()) {
      showNotification("Faltan datos", "error")
      return
    }

    const supabase = createClient()
    const data = {
      ciudadano_nombre: ciudadano.trim(),
      tiempo: tiempoNum,
      fianza: fianzaNum,
      cargos: cargos.trim(),
      oficial_nombre: user?.nombre,
      oficial_id: user?.id,
      servidor_id: serverId,
      estado: "en_custodia",
    }

    const { error } = await supabase.from("arrestos").insert([data])

    if (error) {
      showNotification("Error: " + error.message, "error")
      return
    }

    await supabase.from("auditoria").insert([{
      usuario_id: user?.id,
      usuario_nombre: user?.nombre,
      servidor_id: serverId,
      accion: "crear",
      modulo: "arrestos",
      descripcion: `Detenido: ${data.ciudadano_nombre}, Tiempo: ${data.tiempo} meses`,
      fecha_hora: new Date().toISOString(),
    }])

    setModalOpen(false)
    loadArrestos()
    showNotification("Arresto procesado", "success")
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin w-8 h-8 border-4 border-pda-accent border-t-transparent rounded-full" />
      </div>
    )
  }

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-3xl font-bold tracking-wide text-white flex items-center gap-3">
          <HandMetal className="w-7 h-7 text-pda-accent" /> REGISTRO DE ARRESTOS
        </h2>
        <p className="text-pda-muted font-semibold mt-1">Detenciones y procedimientos penales</p>
      </div>

      <Section
        actions={
          <div className="flex gap-3 flex-wrap">
            <SearchInput value={search} onChange={setSearch} placeholder="Buscar detenido..." />
            <Button variant="accent" onClick={openModal}>
              <Plus className="w-4 h-4" /> NUEVO ARRESTO
            </Button>
          </div>
        }
      >
        {filtered.length > 0 ? (
          <div className="space-y-3">
            {filtered.map((a) => (
              <ListItem
                key={a.id}
                title={
                  <span className="flex items-center gap-2">
                    <UserX className="w-4 h-4" /> {a.ciudadano_nombre}
                  </span>
                }
                meta={[
                  <span key="pena" className="flex items-center gap-1.5">
                    <Clock className="w-4 h-4" /> Pena: {a.tiempo} meses | Fianza: ${a.fianza || "0"}
                  </span>,
                  <span key="oficial" className="flex items-center gap-1.5">
                    <UserCheck className="w-4 h-4" /> Oficial: {a.oficial_nombre}
                  </span>,
                  <span key="fecha" className="flex items-center gap-1.5">
                    <Calendar className="w-4 h-4" /> {formatDate(a.created_at)}
                  </span>,
                ]}
                description={`Cargos: ${a.cargos}`}
              />
            ))}
          </div>
        ) : (
          <EmptyState icon={<LockOpen className="w-12 h-12" />} message="No hay arrestos recientes" />
        )}
      </Section>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="NUEVO ARRESTO">
        <FormGrid>
          <Input label="Detenido" value={ciudadano} onChange={setCiudadano} required />
          <Input label="Tiempo (Meses)" value={tiempo} onChange={setTiempo} type="number" required />
          <Input label="Fianza ($)" value={fianza} onChange={setFianza} type="number" />
          <FormFullWidth>
            <Textarea label="Cargos" value={cargos} onChange={setCargos} required />
          </FormFullWidth>
        </FormGrid>
        <ModalActions>
          <Button onClick={() => setModalOpen(false)}>CANCELAR</Button>
          <Button variant="accent" onClick={handleSave}>PROCESAR</Button>
        </ModalActions>
      </Modal>
    </div>
  )
}
