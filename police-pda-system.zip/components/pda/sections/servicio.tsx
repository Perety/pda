"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"
import { showNotification } from "@/components/pda/notification"
import { Section, ListItem, EmptyState } from "@/components/pda/ui-elements"
import { CircleCheck, Power, PhoneOff, Coffee, Shield as UserShield, Award, Clock } from "lucide-react"
import type { Servicio } from "@/lib/types"

function formatDate(dateString: string) {
  if (!dateString) return ""
  const date = new Date(dateString)
  return date.toLocaleDateString("es-ES", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })
}

export function ServicioSection() {
  const { user, serverId, activeServiceId, setActiveServiceId, checkActiveService } = useAuth()
  const [servicios, setServicios] = useState<Servicio[]>([])
  const [currentStatus, setCurrentStatus] = useState<string>("disponible")
  const [loading, setLoading] = useState(true)

  const loadServicioActivo = async () => {
    if (!serverId) return
    const supabase = createClient()
    const { data } = await supabase
      .from("servicio")
      .select("*, usuarios(nombre, placa, rango)")
      .eq("servidor_id", serverId)
      .is("hora_fin", null)
      .order("hora_inicio", { ascending: false })
    setServicios((data || []) as Servicio[])
    setLoading(false)
  }

  const loadCurrentStatus = async () => {
    if (!activeServiceId) return
    const supabase = createClient()
    const { data } = await supabase.from("servicio").select("estado").eq("id", activeServiceId).single()
    if (data) setCurrentStatus(data.estado)
  }

  useEffect(() => {
    checkActiveService()
    loadServicioActivo()
  }, [serverId])

  useEffect(() => {
    loadCurrentStatus()
  }, [activeServiceId])

  const toggleService = async () => {
    const supabase = createClient()
    
    if (activeServiceId) {
      // Salir de servicio
      await supabase.from("servicio").update({ hora_fin: new Date().toISOString(), estado: "offline" }).eq("id", activeServiceId)
      setActiveServiceId(null)
      showNotification("Has salido de servicio", "info")
    } else {
      // Entrar en servicio
      const { data, error } = await supabase
        .from("servicio")
        .insert([{
          usuario_id: user?.id,
          servidor_id: serverId,
          hora_inicio: new Date().toISOString(),
          estado: "disponible",
        }])
        .select()
        .single()

      if (!error && data) {
        setActiveServiceId(data.id)
        setCurrentStatus("disponible")
        showNotification("Ahora estás en servicio", "success")
      }
    }
    loadServicioActivo()
  }

  const setServiceStatus = async (status: string) => {
    if (!activeServiceId) {
      showNotification("Debes entrar en servicio primero", "error")
      return
    }

    const supabase = createClient()
    await supabase.from("servicio").update({ estado: status }).eq("id", activeServiceId)
    setCurrentStatus(status)
    showNotification(`Estado cambiado a: ${status.toUpperCase()}`, "info")
    loadServicioActivo()
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin w-8 h-8 border-4 border-pda-accent border-t-transparent rounded-full" />
      </div>
    )
  }

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-3xl font-bold tracking-wide text-white flex items-center gap-3">
          <CircleCheck className="w-7 h-7 text-pda-accent" /> CONTROL DE SERVICIO
        </h2>
        <p className="text-pda-muted font-semibold mt-1">Gestión de estado y fichaje</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <button
          onClick={toggleService}
          className={`p-5 text-center rounded-xl border-2 font-bold uppercase transition-all hover:-translate-y-0.5 ${
            activeServiceId
              ? "border-pda-success bg-pda-success/10 text-pda-success"
              : "border-pda-border bg-pda-card text-pda-muted hover:border-pda-accent"
          }`}
        >
          <Power className="w-6 h-6 mx-auto mb-2" />
          <span>{activeServiceId ? "SALIR DE SERVICIO" : "ENTRAR EN SERVICIO"}</span>
        </button>

        <button
          onClick={() => setServiceStatus("ocupado")}
          className={`p-5 text-center rounded-xl border-2 font-bold uppercase transition-all hover:-translate-y-0.5 ${
            activeServiceId && currentStatus === "ocupado"
              ? "border-pda-danger bg-pda-danger/10 text-pda-danger"
              : "border-pda-border bg-pda-card text-pda-muted hover:border-pda-danger"
          }`}
        >
          <PhoneOff className="w-6 h-6 mx-auto mb-2" />
          <span>OCUPADO / 10-6</span>
        </button>

        <button
          onClick={() => setServiceStatus("descanso")}
          className={`p-5 text-center rounded-xl border-2 font-bold uppercase transition-all hover:-translate-y-0.5 ${
            activeServiceId && currentStatus === "descanso"
              ? "border-pda-warning bg-pda-warning/10 text-pda-warning"
              : "border-pda-border bg-pda-card text-pda-muted hover:border-pda-warning"
          }`}
        >
          <Coffee className="w-6 h-6 mx-auto mb-2" />
          <span>DESCANSO / 10-7</span>
        </button>
      </div>

      <Section title="Oficiales Activos Ahora">
        {servicios.length > 0 ? (
          <div className="space-y-3">
            {servicios.map((s) => {
              const statusColor = s.estado === "ocupado" ? "danger" : s.estado === "descanso" ? "warning" : "success"
              return (
                <ListItem
                  key={s.id}
                  title={
                    <span className="flex items-center gap-2">
                      <UserShield className="w-4 h-4" /> {s.usuarios?.rango} {s.usuarios?.nombre}
                    </span>
                  }
                  meta={[
                    <span key="placa" className="flex items-center gap-1.5">
                      <Award className="w-4 h-4" /> Placa: {s.usuarios?.placa}
                    </span>,
                    <span key="desde" className="flex items-center gap-1.5">
                      <Clock className="w-4 h-4" /> En servicio desde: {formatDate(s.hora_inicio)}
                    </span>,
                  ]}
                  tag={{ label: s.estado.toUpperCase(), color: statusColor }}
                />
              )
            })}
          </div>
        ) : (
          <EmptyState icon={<Coffee className="w-12 h-12" />} message="No hay oficiales en servicio" />
        )}
      </Section>
    </div>
  )
}
