"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"
import { StatCard, Section, ListItem, EmptyState, Tag } from "@/components/pda/ui-elements"
import { Gauge, Users, UserCog, CircleCheck, Award as IdCard, FileText, Clock, History, Lock } from "lucide-react"
import type { Auditoria } from "@/lib/types"

function formatDate(dateString: string) {
  if (!dateString) return ""
  const date = new Date(dateString)
  return date.toLocaleDateString("es-ES", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })
}

interface AdminStats {
  usuarios: number
  oficiales: number
  enServicio: number
  ciudadanos: number
  multas: number
}

export function AdminPanelSection() {
  const { user, serverId } = useAuth()
  const [stats, setStats] = useState<AdminStats>({
    usuarios: 0,
    oficiales: 0,
    enServicio: 0,
    ciudadanos: 0,
    multas: 0,
  })
  const [actividad, setActividad] = useState<Auditoria[]>([])
  const [loading, setLoading] = useState(true)

  const isAdmin = user?.rol === "admin" || user?.rol === "superadmin"

  useEffect(() => {
    if (!serverId || !isAdmin) {
      setLoading(false)
      return
    }

    async function loadStats() {
      const supabase = createClient()

      const [usuariosRes, servicioRes, ciudadanosRes, multasRes, auditoriaRes] = await Promise.all([
        supabase.from("usuarios").select("rol", { count: "exact" }).eq("servidor_id", serverId),
        supabase.from("servicio").select("*", { count: "exact", head: true }).eq("servidor_id", serverId).is("hora_fin", null),
        supabase.from("ciudadanos").select("*", { count: "exact", head: true }).eq("servidor_id", serverId),
        supabase.from("multas").select("*", { count: "exact", head: true }).eq("servidor_id", serverId),
        supabase.from("auditoria").select("*").eq("servidor_id", serverId).order("fecha_hora", { ascending: false }).limit(10),
      ])

      const oficiales = usuariosRes.data?.filter((u) => u.rol === "oficial").length || 0

      setStats({
        usuarios: usuariosRes.count || 0,
        oficiales,
        enServicio: servicioRes.count || 0,
        ciudadanos: ciudadanosRes.count || 0,
        multas: multasRes.count || 0,
      })

      setActividad((auditoriaRes.data || []) as Auditoria[])
      setLoading(false)
    }

    loadStats()
  }, [serverId, isAdmin])

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-pda-muted">
        <Lock className="w-16 h-16 mb-4 opacity-50" />
        <p className="text-lg font-semibold">Acceso denegado - Solo administradores</p>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin w-8 h-8 border-4 border-pda-accent border-t-transparent rounded-full" />
      </div>
    )
  }

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-3xl font-bold tracking-wide text-white flex items-center gap-3">
          <Gauge className="w-7 h-7 text-pda-accent" /> PANEL DE ADMINISTRACIÓN
        </h2>
        <p className="text-pda-muted font-semibold mt-1">Estadísticas y métricas del servidor</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-6">
        <StatCard title="Total Usuarios" value={stats.usuarios} icon={<Users className="w-5 h-5" />} />
        <StatCard title="Oficiales" value={stats.oficiales} icon={<UserCog className="w-5 h-5" />} color="success" />
        <StatCard title="En Servicio" value={stats.enServicio} icon={<CircleCheck className="w-5 h-5" />} color="success" />
        <StatCard title="Ciudadanos" value={stats.ciudadanos} icon={<IdCard className="w-5 h-5" />} />
        <StatCard title="Multas" value={stats.multas} icon={<FileText className="w-5 h-5" />} color="warning" />
      </div>

      <Section title="Actividad Reciente (Últimas 10)">
        {actividad.length > 0 ? (
          <div className="space-y-3">
            {actividad.map((a) => (
              <ListItem
                key={a.id}
                title={
                  <span className="flex items-center gap-2">
                    <History className="w-4 h-4" /> {a.accion.toUpperCase()}
                  </span>
                }
                meta={[
                  <span key="usuario" className="flex items-center gap-1.5">
                    <Users className="w-4 h-4" /> {a.usuario_nombre} | {formatDate(a.fecha_hora)}
                  </span>,
                  <span key="desc">{a.descripcion || a.detalles}</span>,
                ]}
                tag={{ label: a.modulo.toUpperCase(), color: "info" }}
              />
            ))}
          </div>
        ) : (
          <EmptyState icon={<Clock className="w-12 h-12" />} message="No hay actividad reciente" />
        )}
      </Section>
    </div>
  )
}
