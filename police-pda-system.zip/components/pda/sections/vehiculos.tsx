"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth-context"
import { Modal, ModalActions } from "@/components/pda/modal"
import { showNotification } from "@/components/pda/notification"
import { Section, ListItem, Button, EmptyState, SearchInput, Input, Textarea, Select, FormGrid, FormFullWidth } from "@/components/pda/ui-elements"
import { Car, User, Palette, Pencil, Trash2, Plus } from "lucide-react"
import type { Vehiculo } from "@/lib/types"

export function VehiculosSection() {
  const { user, serverId } = useAuth()
  const [vehiculos, setVehiculos] = useState<Vehiculo[]>([])
  const [search, setSearch] = useState("")
  const [loading, setLoading] = useState(true)
  const [modalOpen, setModalOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  
  // Form state
  const [matricula, setMatricula] = useState("")
  const [modelo, setModelo] = useState("")
  const [color, setColor] = useState("")
  const [propietario, setPropietario] = useState("")
  const [estado, setEstado] = useState("Normal")
  const [notas, setNotas] = useState("")

  const isAdmin = user?.rol === "admin" || user?.rol === "superadmin"

  const loadVehiculos = async () => {
    if (!serverId) return
    const supabase = createClient()
    const { data } = await supabase
      .from("vehiculos")
      .select("*")
      .eq("servidor_id", serverId)
      .order("created_at", { ascending: false })
    setVehiculos(data || [])
    setLoading(false)
  }

  useEffect(() => {
    loadVehiculos()
  }, [serverId])

  const filtered = vehiculos.filter(
    (v) =>
      v.matricula.toLowerCase().includes(search.toLowerCase()) ||
      v.modelo?.toLowerCase().includes(search.toLowerCase()) ||
      v.propietario_nombre?.toLowerCase().includes(search.toLowerCase())
  )

  const openModal = async (id?: string) => {
    if (id) {
      const supabase = createClient()
      const { data } = await supabase.from("vehiculos").select("*").eq("id", id).single()
      if (data) {
        setEditingId(id)
        setMatricula(data.matricula)
        setModelo(data.modelo || "")
        setColor(data.color || "")
        setPropietario(data.propietario_nombre || "")
        setEstado(data.estado || "Normal")
        setNotas(data.notas || "")
      }
    } else {
      setEditingId(null)
      setMatricula("")
      setModelo("")
      setColor("")
      setPropietario("")
      setEstado("Normal")
      setNotas("")
    }
    setModalOpen(true)
  }

  const handleSave = async () => {
    if (!matricula.trim() || !modelo.trim()) {
      showNotification("Faltan datos obligatorios", "error")
      return
    }

    const supabase = createClient()
    const data = {
      matricula: matricula.trim(),
      modelo: modelo.trim(),
      color: color.trim(),
      propietario_nombre: propietario.trim(),
      estado,
      notas: notas.trim(),
      servidor_id: serverId,
      oficial_registro: user?.nombre,
    }

    let result
    if (editingId) {
      result = await supabase.from("vehiculos").update(data).eq("id", editingId)
    } else {
      result = await supabase.from("vehiculos").insert([data])
    }

    if (result.error) {
      showNotification("Error al guardar: " + result.error.message, "error")
      return
    }

    await supabase.from("auditoria").insert([{
      usuario_id: user?.id,
      usuario_nombre: user?.nombre,
      servidor_id: serverId,
      accion: editingId ? "editar" : "crear",
      modulo: "vehiculos",
      descripcion: `Matrícula: ${data.matricula}`,
      fecha_hora: new Date().toISOString(),
    }])

    setModalOpen(false)
    loadVehiculos()
    showNotification("Guardado correctamente", "success")
  }

  const handleDelete = async (id: string, mat: string) => {
    if (!confirm(`¿Eliminar vehículo ${mat}?`)) return
    
    const supabase = createClient()
    await supabase.from("vehiculos").delete().eq("id", id)
    
    await supabase.from("auditoria").insert([{
      usuario_id: user?.id,
      usuario_nombre: user?.nombre,
      servidor_id: serverId,
      accion: "eliminar",
      modulo: "vehiculos",
      descripcion: `Matrícula: ${mat}`,
      fecha_hora: new Date().toISOString(),
    }])

    loadVehiculos()
    showNotification("Eliminado", "success")
  }

  const getEstadoColor = (e: string) => {
    if (e === "Buscado") return "warning"
    if (e === "Robado") return "danger"
    return "success"
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin w-8 h-8 border-4 border-pda-accent border-t-transparent rounded-full" />
      </div>
    )
  }

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-3xl font-bold tracking-wide text-white flex items-center gap-3">
          <Car className="w-7 h-7 text-pda-accent" /> REGISTRO DE VEHÍCULOS
        </h2>
        <p className="text-pda-muted font-semibold mt-1">Base de datos vehicular</p>
      </div>

      <Section
        actions={
          <div className="flex gap-3 flex-wrap">
            <SearchInput value={search} onChange={setSearch} placeholder="Matrícula, modelo o propietario..." />
            <Button variant="accent" onClick={() => openModal()}>
              <Plus className="w-4 h-4" /> NUEVO
            </Button>
          </div>
        }
      >
        {filtered.length > 0 ? (
          <div className="space-y-3">
            {filtered.map((v) => (
              <ListItem
                key={v.id}
                title={
                  <span className="flex items-center gap-2">
                    <Car className="w-4 h-4" /> {v.matricula} - {v.marca} {v.modelo}
                  </span>
                }
                meta={[
                  <span key="prop" className="flex items-center gap-1.5">
                    <User className="w-4 h-4" /> Propietario: {v.propietario_nombre || "Desconocido"}
                  </span>,
                  <span key="color" className="flex items-center gap-1.5">
                    <Palette className="w-4 h-4" /> {v.color} | Estado: <strong>{v.estado}</strong>
                  </span>,
                ]}
                description={v.notas || undefined}
                tag={{ label: v.estado, color: getEstadoColor(v.estado) }}
                actions={
                  <>
                    <Button onClick={() => openModal(v.id)}>
                      <Pencil className="w-4 h-4" /> EDITAR
                    </Button>
                    {isAdmin && (
                      <Button variant="danger" onClick={() => handleDelete(v.id, v.matricula)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </>
                }
              />
            ))}
          </div>
        ) : (
          <EmptyState icon={<Car className="w-12 h-12" />} message="No se encontraron vehículos" />
        )}
      </Section>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editingId ? "EDITAR VEHÍCULO" : "NUEVO VEHÍCULO"}>
        <FormGrid>
          <Input label="Matrícula" value={matricula} onChange={setMatricula} required />
          <Input label="Marca/Modelo" value={modelo} onChange={setModelo} required />
          <Input label="Color" value={color} onChange={setColor} />
          <Input label="Propietario" value={propietario} onChange={setPropietario} />
          <Select
            label="Estado"
            value={estado}
            onChange={setEstado}
            options={[
              { value: "Normal", label: "Normal" },
              { value: "Buscado", label: "Buscado" },
              { value: "Robado", label: "Robado" },
            ]}
          />
          <FormFullWidth>
            <Textarea label="Notas" value={notas} onChange={setNotas} />
          </FormFullWidth>
        </FormGrid>
        <ModalActions>
          <Button onClick={() => setModalOpen(false)}>CANCELAR</Button>
          <Button variant="accent" onClick={handleSave}>GUARDAR</Button>
        </ModalActions>
      </Modal>
    </div>
  )
}
