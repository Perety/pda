"use client"

import { useState, useCallback } from "react"
import { useAuth } from "@/lib/auth-context"
import { LoginScreen } from "@/components/pda/login-screen"
import { Header } from "@/components/pda/header"
import { Sidebar, type SectionName } from "@/components/pda/sidebar"
import { NotificationContainer } from "@/components/pda/notification"

// Sections
import { DashboardSection } from "@/components/pda/sections/dashboard"
import { CiudadanosSection } from "@/components/pda/sections/ciudadanos"
import { VehiculosSection } from "@/components/pda/sections/vehiculos"
import { MultasSection } from "@/components/pda/sections/multas"
import { ArrestosSection } from "@/components/pda/sections/arrestos"
import { LlamadasSection } from "@/components/pda/sections/llamadas"
import { BoloSection } from "@/components/pda/sections/bolo"
import { DenunciasSection } from "@/components/pda/sections/denuncias"
import { InvestigacionesSection } from "@/components/pda/sections/investigaciones"
import { ServicioSection } from "@/components/pda/sections/servicio"
import { AdminPanelSection } from "@/components/pda/sections/admin-panel"
import { AdminUsuariosSection } from "@/components/pda/sections/admin-usuarios"
import { AuditoriaSection } from "@/components/pda/sections/auditoria"

export function PDAApp() {
  const { user, checkActiveService, isReady } = useAuth()
  const [activeSection, setActiveSection] = useState<SectionName>("dashboard")
  const [llamadasCount, setLlamadasCount] = useState(0)

  const handleLoginSuccess = useCallback(() => {
    checkActiveService()
    setActiveSection("dashboard")
  }, [checkActiveService])

  if (!isReady) {
    return (
      <div className="min-h-screen bg-pda-primary flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-pda-accent border-t-transparent rounded-full animate-spin" />
          <p className="text-pda-text-secondary">Cargando sistema...</p>
        </div>
      </div>
    )
  }

  const renderSection = () => {
    switch (activeSection) {
      case "dashboard":
        return <DashboardSection />
      case "ciudadanos":
        return <CiudadanosSection />
      case "vehiculos":
        return <VehiculosSection />
      case "multas":
        return <MultasSection />
      case "arrestos":
        return <ArrestosSection />
      case "llamadas":
        return <LlamadasSection onCountChange={setLlamadasCount} />
      case "bolo":
        return <BoloSection />
      case "denuncias":
        return <DenunciasSection />
      case "investigaciones":
        return <InvestigacionesSection />
      case "servicio":
        return <ServicioSection />
      case "admin-panel":
        return <AdminPanelSection />
      case "admin-usuarios":
        return <AdminUsuariosSection />
      case "auditoria":
        return <AuditoriaSection />
      default:
        return <DashboardSection />
    }
  }

  if (!user) {
    return (
      <>
        <LoginScreen onLoginSuccess={handleLoginSuccess} />
        <NotificationContainer />
      </>
    )
  }

  return (
    <div className="min-h-screen bg-pda-primary">
      <Header />
      <div className="flex h-[calc(100vh-73px)]">
        <Sidebar
          activeSection={activeSection}
          onSectionChange={setActiveSection}
          llamadasCount={llamadasCount}
        />
        <main className="flex-1 overflow-y-auto p-6 bg-pda-primary">
          {renderSection()}
        </main>
      </div>
      <NotificationContainer />
    </div>
  )
}
