"use client"

import React from "react"

import { useState, useEffect, useCallback, createContext, useContext, type ReactNode } from "react"
import { createBrowserClient } from "@supabase/ssr"
import {
  Shield, LogOut, Menu, X, Home, Users, Car, FileText, Gavel, Phone, AlertTriangle,
  FileWarning, Search, Clock, Settings, UserCog, History, Bell, ChevronDown,
  Plus, Pencil, Trash2, Eye, CheckCircle, XCircle, Coffee, Power, Award,
  MapPin, Calendar, DollarSign, User, Hash, Palette, RefreshCw
} from "lucide-react"

// ============================================================================
// TYPES
// ============================================================================

type ThemeColor = "cyan" | "blue" | "green" | "purple" | "red"
type SectionName = "dashboard" | "ciudadanos" | "vehiculos" | "multas" | "arrestos" | 
  "llamadas" | "bolo" | "denuncias" | "investigaciones" | "servicio" | 
  "admin" | "admin-usuarios" | "auditoria"

interface Servidor {
  id: string
  nombre: string
  activo: boolean
}

interface Usuario {
  id: string
  servidor_id: string
  username: string
  nombre_completo: string
  rango: string
  placa: string
  rol: "officer" | "supervisor" | "admin"
  activo: boolean
}

interface Ciudadano {
  id: string
  servidor_id: string
  nombre: string
  apellido: string
  dni: string
  telefono?: string
  direccion?: string
  fecha_nacimiento?: string
  notas?: string
}

interface Vehiculo {
  id: string
  servidor_id: string
  placa: string
  marca: string
  modelo: string
  color: string
  propietario_id?: string
  robado: boolean
  notas?: string
}

interface Multa {
  id: string
  servidor_id: string
  ciudadano_id: string
  oficial_id: string
  motivo: string
  monto: number
  pagada: boolean
  fecha: string
}

interface Arresto {
  id: string
  servidor_id: string
  ciudadano_id: string
  oficial_id: string
  cargos: string
  tiempo_condena: number
  fecha: string
  notas?: string
}

interface Llamada {
  id: string
  servidor_id: string
  tipo: string
  ubicacion: string
  descripcion: string
  estado: "pendiente" | "en_curso" | "completada"
  oficial_asignado_id?: string
  fecha: string
}

interface BOLO {
  id: string
  servidor_id: string
  tipo: "persona" | "vehiculo"
  descripcion: string
  activo: boolean
  creado_por_id: string
  fecha: string
}

interface Denuncia {
  id: string
  servidor_id: string
  denunciante_id?: string
  descripcion: string
  estado: "pendiente" | "investigando" | "cerrada"
  fecha: string
}

interface Investigacion {
  id: string
  servidor_id: string
  titulo: string
  descripcion: string
  estado: "abierta" | "en_progreso" | "cerrada"
  oficial_cargo_id: string
  fecha: string
}

interface Servicio {
  id: string
  servidor_id: string
  oficial_id: string
  hora_entrada: string
  hora_salida?: string
  estado: "activo" | "pausa" | "finalizado"
}

// ============================================================================
// SUPABASE CLIENT
// ============================================================================

let supabaseClient: ReturnType<typeof createBrowserClient> | null = null

function getSupabase() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  
  if (!url || !key) {
    throw new Error("Faltan las variables de entorno de Supabase")
  }
  
  if (!supabaseClient) {
    supabaseClient = createBrowserClient(url, key)
  }
  return supabaseClient
}

// ============================================================================
// AUTH CONTEXT
// ============================================================================

interface AuthContextType {
  user: Usuario | null
  serverId: string | null
  activeServiceId: string | null
  theme: ThemeColor
  login: (serverId: string, username: string, password: string) => Promise<{ success: boolean; error?: string }>
  logout: () => void
  setActiveServiceId: (id: string | null) => void
  setTheme: (theme: ThemeColor) => void
  checkActiveService: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | null>(null)

function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error("useAuth must be used within AuthProvider")
  return ctx
}

function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<Usuario | null>(null)
  const [serverId, setServerId] = useState<string | null>(null)
  const [activeServiceId, setActiveServiceId] = useState<string | null>(null)
  const [theme, setThemeState] = useState<ThemeColor>("cyan")

  useEffect(() => {
    const saved = localStorage.getItem("pda-theme") as ThemeColor
    if (saved) {
      setThemeState(saved)
      document.documentElement.setAttribute("data-theme", saved)
    }
  }, [])

  const login = useCallback(async (sId: string, username: string, password: string) => {
    try {
      const supabase = getSupabase()
      const { data, error } = await supabase
        .from("usuarios")
        .select("*")
        .eq("servidor_id", sId)
        .eq("username", username)
        .eq("password", password)
        .eq("activo", true)
        .single()

      if (error || !data) {
        return { success: false, error: "Credenciales inválidas" }
      }

      setUser(data)
      setServerId(sId)
      
      await supabase.from("auditoria").insert({
        servidor_id: sId,
        usuario_id: data.id,
        accion: "LOGIN",
        detalles: `Usuario ${data.username} inició sesión`
      })

      return { success: true }
    } catch {
      return { success: false, error: "Error de conexión" }
    }
  }, [])

  const logout = useCallback(() => {
    if (user && serverId) {
      try {
        const supabase = getSupabase()
        supabase.from("auditoria").insert({
          servidor_id: serverId,
          usuario_id: user.id,
          accion: "LOGOUT",
          detalles: `Usuario ${user.username} cerró sesión`
        })
      } catch {}
    }
    setUser(null)
    setServerId(null)
    setActiveServiceId(null)
  }, [user, serverId])

  const setTheme = useCallback((t: ThemeColor) => {
    setThemeState(t)
    localStorage.setItem("pda-theme", t)
    document.documentElement.setAttribute("data-theme", t)
  }, [])

  const checkActiveService = useCallback(async () => {
    if (!user || !serverId) return
    try {
      const supabase = getSupabase()
      const { data } = await supabase
        .from("servicios")
        .select("id")
        .eq("servidor_id", serverId)
        .eq("oficial_id", user.id)
        .eq("estado", "activo")
        .single()
      setActiveServiceId(data?.id || null)
    } catch {
      setActiveServiceId(null)
    }
  }, [user, serverId])

  return (
    <AuthContext.Provider value={{
      user, serverId, activeServiceId, theme,
      login, logout, setActiveServiceId, setTheme, checkActiveService
    }}>
      {children}
    </AuthContext.Provider>
  )
}

// ============================================================================
// UI COMPONENTS
// ============================================================================

function PDAButton({ 
  children, 
  variant = "primary", 
  size = "md",
  className = "",
  ...props 
}: {
  children: ReactNode
  variant?: "primary" | "secondary" | "danger" | "success" | "ghost"
  size?: "sm" | "md" | "lg"
  className?: string
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const variants = {
    primary: "bg-[var(--pda-accent)] hover:bg-[var(--pda-accent-hover)] text-white",
    secondary: "bg-[var(--pda-card)] hover:bg-[var(--pda-hover)] text-[var(--pda-text)] border border-[var(--pda-border)]",
    danger: "bg-[var(--pda-danger)] hover:opacity-90 text-white",
    success: "bg-[var(--pda-success)] hover:opacity-90 text-white",
    ghost: "bg-transparent hover:bg-[var(--pda-hover)] text-[var(--pda-text-secondary)]"
  }
  const sizes = {
    sm: "px-2 py-1 text-xs",
    md: "px-4 py-2 text-sm",
    lg: "px-6 py-3 text-base"
  }

  return (
    <button
      className={`rounded-lg font-medium transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  )
}

function PDAInput({
  label,
  className = "",
  ...props
}: {
  label?: string
  className?: string
} & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div className="flex flex-col gap-1">
      {label && <label className="text-xs text-[var(--pda-text-secondary)] font-medium">{label}</label>}
      <input
        className={`bg-[var(--pda-secondary)] border border-[var(--pda-border)] rounded-lg px-3 py-2 text-[var(--pda-text)] placeholder:text-[var(--pda-muted)] focus:outline-none focus:border-[var(--pda-accent)] transition-colors ${className}`}
        {...props}
      />
    </div>
  )
}

function PDASelect({
  label,
  options,
  className = "",
  ...props
}: {
  label?: string
  options: { value: string; label: string }[]
  className?: string
} & React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <div className="flex flex-col gap-1">
      {label && <label className="text-xs text-[var(--pda-text-secondary)] font-medium">{label}</label>}
      <select
        className={`bg-[var(--pda-secondary)] border border-[var(--pda-border)] rounded-lg px-3 py-2 text-[var(--pda-text)] focus:outline-none focus:border-[var(--pda-accent)] transition-colors ${className}`}
        {...props}
      >
        {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  )
}

function PDATextarea({
  label,
  className = "",
  ...props
}: {
  label?: string
  className?: string
} & React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <div className="flex flex-col gap-1">
      {label && <label className="text-xs text-[var(--pda-text-secondary)] font-medium">{label}</label>}
      <textarea
        className={`bg-[var(--pda-secondary)] border border-[var(--pda-border)] rounded-lg px-3 py-2 text-[var(--pda-text)] placeholder:text-[var(--pda-muted)] focus:outline-none focus:border-[var(--pda-accent)] transition-colors resize-none ${className}`}
        {...props}
      />
    </div>
  )
}

function PDACard({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div className={`bg-[var(--pda-card)] rounded-xl border border-[var(--pda-border)] p-4 ${className}`}>
      {children}
    </div>
  )
}

function PDAModal({
  isOpen,
  onClose,
  title,
  children
}: {
  isOpen: boolean
  onClose: () => void
  title: string
  children: ReactNode
}) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-[var(--pda-secondary)] rounded-2xl border border-[var(--pda-border)] w-full max-w-lg max-h-[90vh] overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between p-4 border-b border-[var(--pda-border)]">
          <h2 className="text-lg font-semibold text-[var(--pda-text)]">{title}</h2>
          <button onClick={onClose} className="text-[var(--pda-muted)] hover:text-[var(--pda-text)] transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-4 overflow-y-auto max-h-[calc(90vh-80px)]">
          {children}
        </div>
      </div>
    </div>
  )
}

function StatCard({ icon: Icon, label, value, color }: { icon: React.ElementType; label: string; value: number; color: string }) {
  return (
    <div className="bg-[var(--pda-card)] rounded-xl border border-[var(--pda-border)] p-4">
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${color}`}>
          <Icon className="w-5 h-5 text-white" />
        </div>
        <div>
          <p className="text-2xl font-bold text-[var(--pda-text)]">{value}</p>
          <p className="text-xs text-[var(--pda-text-secondary)]">{label}</p>
        </div>
      </div>
    </div>
  )
}

function Badge({ children, variant = "default" }: { children: ReactNode; variant?: "default" | "success" | "warning" | "danger" }) {
  const colors = {
    default: "bg-[var(--pda-accent)]/20 text-[var(--pda-accent)]",
    success: "bg-[var(--pda-success)]/20 text-[var(--pda-success)]",
    warning: "bg-[var(--pda-warning)]/20 text-[var(--pda-warning)]",
    danger: "bg-[var(--pda-danger)]/20 text-[var(--pda-danger)]"
  }
  return (
    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${colors[variant]}`}>
      {children}
    </span>
  )
}

// ============================================================================
// LOGIN SCREEN
// ============================================================================

function LoginScreen({ onSuccess }: { onSuccess: () => void }) {
  const { login, setTheme, theme } = useAuth()
  const [servers, setServers] = useState<Servidor[]>([])
  const [selectedServer, setSelectedServer] = useState("")
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [showTheme, setShowTheme] = useState(false)

  useEffect(() => {
    async function loadServers() {
      try {
        const supabase = getSupabase()
        const { data } = await supabase
          .from("servidores")
          .select("*")
          .eq("activo", true)
          .order("nombre")
        if (data) setServers(data)
      } catch (err) {
        setError("Error al conectar con la base de datos")
      }
    }
    loadServers()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedServer || !username || !password) {
      setError("Completa todos los campos")
      return
    }
    setLoading(true)
    setError("")
    const result = await login(selectedServer, username, password)
    setLoading(false)
    if (result.success) {
      onSuccess()
    } else {
      setError(result.error || "Error de autenticación")
    }
  }

  const themes: { value: ThemeColor; label: string; color: string }[] = [
    { value: "cyan", label: "Cyan", color: "bg-cyan-500" },
    { value: "blue", label: "Azul", color: "bg-blue-500" },
    { value: "green", label: "Verde", color: "bg-green-500" },
    { value: "purple", label: "Púrpura", color: "bg-purple-500" },
    { value: "red", label: "Rojo", color: "bg-red-500" }
  ]

  return (
    <div className="min-h-screen bg-[var(--pda-primary)] flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-[var(--pda-secondary)] rounded-2xl border border-[var(--pda-border)] p-8 shadow-2xl">
          <div className="flex flex-col items-center mb-8">
            <div className="w-16 h-16 bg-[var(--pda-accent)] rounded-2xl flex items-center justify-center mb-4">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-[var(--pda-text)]">Sistema PDA</h1>
            <p className="text-[var(--pda-text-secondary)]">Policía Multi-Servidor</p>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <PDASelect
              label="Servidor"
              value={selectedServer}
              onChange={(e) => setSelectedServer(e.target.value)}
              options={[
                { value: "", label: "Seleccionar servidor..." },
                ...servers.map(s => ({ value: s.id, label: s.nombre }))
              ]}
            />

            <PDAInput
              label="Usuario"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Ingresa tu usuario"
            />

            <PDAInput
              label="Contraseña"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Ingresa tu contraseña"
            />

            {error && (
              <p className="text-[var(--pda-danger)] text-sm text-center">{error}</p>
            )}

            <PDAButton type="submit" disabled={loading} className="w-full mt-2">
              {loading ? "Ingresando..." : "Ingresar"}
            </PDAButton>
          </form>

          <div className="mt-6 pt-4 border-t border-[var(--pda-border)]">
            <button
              onClick={() => setShowTheme(!showTheme)}
              className="flex items-center gap-2 text-[var(--pda-text-secondary)] hover:text-[var(--pda-text)] transition-colors w-full justify-center"
            >
              <Palette className="w-4 h-4" />
              <span className="text-sm">Personalizar tema</span>
              <ChevronDown className={`w-4 h-4 transition-transform ${showTheme ? "rotate-180" : ""}`} />
            </button>
            
            {showTheme && (
              <div className="flex justify-center gap-2 mt-3">
                {themes.map(t => (
                  <button
                    key={t.value}
                    onClick={() => setTheme(t.value)}
                    className={`w-8 h-8 rounded-full ${t.color} transition-transform ${theme === t.value ? "ring-2 ring-white ring-offset-2 ring-offset-[var(--pda-secondary)] scale-110" : "hover:scale-105"}`}
                    title={t.label}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

// ============================================================================
// HEADER
// ============================================================================

function Header({ onToggleSidebar }: { onToggleSidebar: () => void }) {
  const { user, logout, activeServiceId } = useAuth()
  const [time, setTime] = useState(new Date())

  useEffect(() => {
    const interval = setInterval(() => setTime(new Date()), 1000)
    return () => clearInterval(interval)
  }, [])

  return (
    <header className="bg-[var(--pda-secondary)] border-b border-[var(--pda-border)] px-4 py-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={onToggleSidebar} className="lg:hidden text-[var(--pda-text)] hover:text-[var(--pda-accent)]">
            <Menu className="w-6 h-6" />
          </button>
          <div className="flex items-center gap-2">
            <Shield className="w-6 h-6 text-[var(--pda-accent)]" />
            <span className="font-bold text-[var(--pda-text)]">PDA Policial</span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden sm:flex items-center gap-2 text-[var(--pda-text-secondary)]">
            <Clock className="w-4 h-4" />
            <span className="text-sm font-mono">
              {time.toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" })}
            </span>
          </div>

          {activeServiceId && (
            <Badge variant="success">En Servicio</Badge>
          )}

          <div className="flex items-center gap-2">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-medium text-[var(--pda-text)]">{user?.nombre_completo}</p>
              <p className="text-xs text-[var(--pda-text-secondary)]">{user?.rango} - #{user?.placa}</p>
            </div>
            <button
              onClick={logout}
              className="p-2 text-[var(--pda-danger)] hover:bg-[var(--pda-danger)]/10 rounded-lg transition-colors"
              title="Cerrar sesión"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}

// ============================================================================
// SIDEBAR
// ============================================================================

const menuItems: { id: SectionName; label: string; icon: React.ElementType; adminOnly?: boolean }[] = [
  { id: "dashboard", label: "Dashboard", icon: Home },
  { id: "ciudadanos", label: "Ciudadanos", icon: Users },
  { id: "vehiculos", label: "Vehículos", icon: Car },
  { id: "multas", label: "Multas", icon: FileText },
  { id: "arrestos", label: "Arrestos", icon: Gavel },
  { id: "llamadas", label: "Llamadas 911", icon: Phone },
  { id: "bolo", label: "BOLO", icon: AlertTriangle },
  { id: "denuncias", label: "Denuncias", icon: FileWarning },
  { id: "investigaciones", label: "Investigaciones", icon: Search },
  { id: "servicio", label: "Mi Servicio", icon: Clock },
  { id: "admin", label: "Admin Panel", icon: Settings, adminOnly: true },
  { id: "admin-usuarios", label: "Usuarios", icon: UserCog, adminOnly: true },
  { id: "auditoria", label: "Auditoría", icon: History, adminOnly: true }
]

function Sidebar({
  isOpen,
  onClose,
  activeSection,
  onSectionChange,
  llamadasCount
}: {
  isOpen: boolean
  onClose: () => void
  activeSection: SectionName
  onSectionChange: (section: SectionName) => void
  llamadasCount: number
}) {
  const { user } = useAuth()
  const isAdmin = user?.rol === "admin"

  const handleClick = (id: SectionName) => {
    onSectionChange(id)
    onClose()
  }

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={onClose} />
      )}
      <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-64 bg-[var(--pda-secondary)] border-r border-[var(--pda-border)] transform transition-transform duration-300 ${isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`}>
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between p-4 lg:hidden border-b border-[var(--pda-border)]">
            <span className="font-bold text-[var(--pda-text)]">Menú</span>
            <button onClick={onClose} className="text-[var(--pda-text)]">
              <X className="w-5 h-5" />
            </button>
          </div>

          <nav className="flex-1 p-4 overflow-y-auto">
            <ul className="flex flex-col gap-1">
              {menuItems.map(item => {
                if (item.adminOnly && !isAdmin) return null
                const Icon = item.icon
                const isActive = activeSection === item.id
                const showBadge = item.id === "llamadas" && llamadasCount > 0

                return (
                  <li key={item.id}>
                    <button
                      onClick={() => handleClick(item.id)}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${
                        isActive
                          ? "bg-[var(--pda-accent)] text-white"
                          : "text-[var(--pda-text-secondary)] hover:bg-[var(--pda-hover)] hover:text-[var(--pda-text)]"
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="flex-1 text-left">{item.label}</span>
                      {showBadge && (
                        <span className="bg-[var(--pda-danger)] text-white text-xs px-2 py-0.5 rounded-full">
                          {llamadasCount}
                        </span>
                      )}
                    </button>
                  </li>
                )
              })}
            </ul>
          </nav>
        </div>
      </aside>
    </>
  )
}

// ============================================================================
// DASHBOARD SECTION
// ============================================================================

function DashboardSection() {
  const { serverId } = useAuth()
  const [stats, setStats] = useState({ ciudadanos: 0, vehiculos: 0, multas: 0, arrestos: 0, llamadas: 0, bolos: 0 })

  useEffect(() => {
    async function loadStats() {
      if (!serverId) return
      const supabase = getSupabase()
      
      const [c, v, m, a, l, b] = await Promise.all([
        supabase.from("ciudadanos").select("id", { count: "exact", head: true }).eq("servidor_id", serverId),
        supabase.from("vehiculos").select("id", { count: "exact", head: true }).eq("servidor_id", serverId),
        supabase.from("multas").select("id", { count: "exact", head: true }).eq("servidor_id", serverId).eq("pagada", false),
        supabase.from("arrestos").select("id", { count: "exact", head: true }).eq("servidor_id", serverId),
        supabase.from("llamadas").select("id", { count: "exact", head: true }).eq("servidor_id", serverId).eq("estado", "pendiente"),
        supabase.from("bolos").select("id", { count: "exact", head: true }).eq("servidor_id", serverId).eq("activo", true)
      ])
      
      setStats({
        ciudadanos: c.count || 0,
        vehiculos: v.count || 0,
        multas: m.count || 0,
        arrestos: a.count || 0,
        llamadas: l.count || 0,
        bolos: b.count || 0
      })
    }
    loadStats()
  }, [serverId])

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-2xl font-bold text-[var(--pda-text)]">Dashboard</h1>
      
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        <StatCard icon={Users} label="Ciudadanos" value={stats.ciudadanos} color="bg-blue-500" />
        <StatCard icon={Car} label="Vehículos" value={stats.vehiculos} color="bg-green-500" />
        <StatCard icon={FileText} label="Multas Pendientes" value={stats.multas} color="bg-yellow-500" />
        <StatCard icon={Gavel} label="Arrestos" value={stats.arrestos} color="bg-red-500" />
        <StatCard icon={Phone} label="Llamadas 911" value={stats.llamadas} color="bg-purple-500" />
        <StatCard icon={AlertTriangle} label="BOLOs Activos" value={stats.bolos} color="bg-orange-500" />
      </div>
    </div>
  )
}

// ============================================================================
// CIUDADANOS SECTION
// ============================================================================

function CiudadanosSection() {
  const { serverId, user } = useAuth()
  const [ciudadanos, setCiudadanos] = useState<Ciudadano[]>([])
  const [search, setSearch] = useState("")
  const [showModal, setShowModal] = useState(false)
  const [editing, setEditing] = useState<Ciudadano | null>(null)
  const [form, setForm] = useState({ nombre: "", apellido: "", dni: "", telefono: "", direccion: "", notas: "" })

  const loadData = useCallback(async () => {
    if (!serverId) return
    const supabase = getSupabase()
    const { data } = await supabase
      .from("ciudadanos")
      .select("*")
      .eq("servidor_id", serverId)
      .order("apellido")
    if (data) setCiudadanos(data)
  }, [serverId])

  useEffect(() => { loadData() }, [loadData])

  const filtered = ciudadanos.filter(c => 
    `${c.nombre} ${c.apellido} ${c.dni}`.toLowerCase().includes(search.toLowerCase())
  )

  const handleSave = async () => {
    if (!serverId || !user) return
    const supabase = getSupabase()
    
    if (editing) {
      await supabase.from("ciudadanos").update(form).eq("id", editing.id)
    } else {
      await supabase.from("ciudadanos").insert({ ...form, servidor_id: serverId })
    }
    
    await supabase.from("auditoria").insert({
      servidor_id: serverId,
      usuario_id: user.id,
      accion: editing ? "UPDATE_CIUDADANO" : "CREATE_CIUDADANO",
      detalles: `${editing ? "Editó" : "Creó"} ciudadano: ${form.nombre} ${form.apellido}`
    })

    setShowModal(false)
    setEditing(null)
    setForm({ nombre: "", apellido: "", dni: "", telefono: "", direccion: "", notas: "" })
    loadData()
  }

  const handleDelete = async (c: Ciudadano) => {
    if (!confirm(`¿Eliminar a ${c.nombre} ${c.apellido}?`)) return
    const supabase = getSupabase()
    await supabase.from("ciudadanos").delete().eq("id", c.id)
    loadData()
  }

  const openEdit = (c: Ciudadano) => {
    setEditing(c)
    setForm({ nombre: c.nombre, apellido: c.apellido, dni: c.dni, telefono: c.telefono || "", direccion: c.direccion || "", notas: c.notas || "" })
    setShowModal(true)
  }

  const openNew = () => {
    setEditing(null)
    setForm({ nombre: "", apellido: "", dni: "", telefono: "", direccion: "", notas: "" })
    setShowModal(true)
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <h1 className="text-2xl font-bold text-[var(--pda-text)]">Ciudadanos</h1>
        <PDAButton onClick={openNew}><Plus className="w-4 h-4 mr-2" />Nuevo</PDAButton>
      </div>

      <PDAInput
        placeholder="Buscar por nombre o DNI..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      <div className="grid gap-4">
        {filtered.map(c => (
          <PDACard key={c.id}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-semibold text-[var(--pda-text)]">{c.nombre} {c.apellido}</h3>
                <div className="flex flex-wrap gap-4 mt-2 text-sm text-[var(--pda-text-secondary)]">
                  <span className="flex items-center gap-1"><Hash className="w-4 h-4" />{c.dni}</span>
                  {c.telefono && <span className="flex items-center gap-1"><Phone className="w-4 h-4" />{c.telefono}</span>}
                </div>
              </div>
              <div className="flex gap-2">
                <PDAButton variant="ghost" size="sm" onClick={() => openEdit(c)}><Pencil className="w-4 h-4" /></PDAButton>
                <PDAButton variant="ghost" size="sm" onClick={() => handleDelete(c)}><Trash2 className="w-4 h-4 text-[var(--pda-danger)]" /></PDAButton>
              </div>
            </div>
          </PDACard>
        ))}
        {filtered.length === 0 && (
          <p className="text-center text-[var(--pda-text-secondary)] py-8">No se encontraron ciudadanos</p>
        )}
      </div>

      <PDAModal isOpen={showModal} onClose={() => setShowModal(false)} title={editing ? "Editar Ciudadano" : "Nuevo Ciudadano"}>
        <div className="flex flex-col gap-4">
          <div className="grid grid-cols-2 gap-4">
            <PDAInput label="Nombre" value={form.nombre} onChange={(e) => setForm({ ...form, nombre: e.target.value })} />
            <PDAInput label="Apellido" value={form.apellido} onChange={(e) => setForm({ ...form, apellido: e.target.value })} />
          </div>
          <PDAInput label="DNI" value={form.dni} onChange={(e) => setForm({ ...form, dni: e.target.value })} />
          <PDAInput label="Teléfono" value={form.telefono} onChange={(e) => setForm({ ...form, telefono: e.target.value })} />
          <PDAInput label="Dirección" value={form.direccion} onChange={(e) => setForm({ ...form, direccion: e.target.value })} />
          <PDATextarea label="Notas" value={form.notas} onChange={(e) => setForm({ ...form, notas: e.target.value })} rows={3} />
          <div className="flex gap-2 justify-end mt-2">
            <PDAButton variant="secondary" onClick={() => setShowModal(false)}>Cancelar</PDAButton>
            <PDAButton onClick={handleSave}>Guardar</PDAButton>
          </div>
        </div>
      </PDAModal>
    </div>
  )
}

// ============================================================================
// VEHICULOS SECTION
// ============================================================================

function VehiculosSection() {
  const { serverId, user } = useAuth()
  const [vehiculos, setVehiculos] = useState<Vehiculo[]>([])
  const [search, setSearch] = useState("")
  const [showModal, setShowModal] = useState(false)
  const [editing, setEditing] = useState<Vehiculo | null>(null)
  const [form, setForm] = useState({ placa: "", marca: "", modelo: "", color: "", robado: false, notas: "" })

  const loadData = useCallback(async () => {
    if (!serverId) return
    const supabase = getSupabase()
    const { data } = await supabase.from("vehiculos").select("*").eq("servidor_id", serverId).order("placa")
    if (data) setVehiculos(data)
  }, [serverId])

  useEffect(() => { loadData() }, [loadData])

  const filtered = vehiculos.filter(v => 
    `${v.placa} ${v.marca} ${v.modelo}`.toLowerCase().includes(search.toLowerCase())
  )

  const handleSave = async () => {
    if (!serverId || !user) return
    const supabase = getSupabase()
    
    if (editing) {
      await supabase.from("vehiculos").update(form).eq("id", editing.id)
    } else {
      await supabase.from("vehiculos").insert({ ...form, servidor_id: serverId })
    }

    setShowModal(false)
    setEditing(null)
    setForm({ placa: "", marca: "", modelo: "", color: "", robado: false, notas: "" })
    loadData()
  }

  const handleDelete = async (v: Vehiculo) => {
    if (!confirm(`¿Eliminar vehículo ${v.placa}?`)) return
    const supabase = getSupabase()
    await supabase.from("vehiculos").delete().eq("id", v.id)
    loadData()
  }

  const toggleRobado = async (v: Vehiculo) => {
    const supabase = getSupabase()
    await supabase.from("vehiculos").update({ robado: !v.robado }).eq("id", v.id)
    loadData()
  }

  const openEdit = (v: Vehiculo) => {
    setEditing(v)
    setForm({ placa: v.placa, marca: v.marca, modelo: v.modelo, color: v.color, robado: v.robado, notas: v.notas || "" })
    setShowModal(true)
  }

  const openNew = () => {
    setEditing(null)
    setForm({ placa: "", marca: "", modelo: "", color: "", robado: false, notas: "" })
    setShowModal(true)
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <h1 className="text-2xl font-bold text-[var(--pda-text)]">Vehículos</h1>
        <PDAButton onClick={openNew}><Plus className="w-4 h-4 mr-2" />Nuevo</PDAButton>
      </div>

      <PDAInput placeholder="Buscar por placa, marca o modelo..." value={search} onChange={(e) => setSearch(e.target.value)} />

      <div className="grid gap-4">
        {filtered.map(v => (
          <PDACard key={v.id}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-[var(--pda-text)]">{v.placa}</h3>
                  {v.robado && <Badge variant="danger">ROBADO</Badge>}
                </div>
                <p className="text-sm text-[var(--pda-text-secondary)]">{v.marca} {v.modelo} - {v.color}</p>
              </div>
              <div className="flex gap-2">
                <PDAButton variant={v.robado ? "danger" : "secondary"} size="sm" onClick={() => toggleRobado(v)}>
                  {v.robado ? "Quitar Robo" : "Marcar Robado"}
                </PDAButton>
                <PDAButton variant="ghost" size="sm" onClick={() => openEdit(v)}><Pencil className="w-4 h-4" /></PDAButton>
                <PDAButton variant="ghost" size="sm" onClick={() => handleDelete(v)}><Trash2 className="w-4 h-4 text-[var(--pda-danger)]" /></PDAButton>
              </div>
            </div>
          </PDACard>
        ))}
        {filtered.length === 0 && <p className="text-center text-[var(--pda-text-secondary)] py-8">No se encontraron vehículos</p>}
      </div>

      <PDAModal isOpen={showModal} onClose={() => setShowModal(false)} title={editing ? "Editar Vehículo" : "Nuevo Vehículo"}>
        <div className="flex flex-col gap-4">
          <PDAInput label="Placa" value={form.placa} onChange={(e) => setForm({ ...form, placa: e.target.value })} />
          <div className="grid grid-cols-2 gap-4">
            <PDAInput label="Marca" value={form.marca} onChange={(e) => setForm({ ...form, marca: e.target.value })} />
            <PDAInput label="Modelo" value={form.modelo} onChange={(e) => setForm({ ...form, modelo: e.target.value })} />
          </div>
          <PDAInput label="Color" value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} />
          <label className="flex items-center gap-2 text-[var(--pda-text)]">
            <input type="checkbox" checked={form.robado} onChange={(e) => setForm({ ...form, robado: e.target.checked })} className="w-4 h-4" />
            Vehículo Robado
          </label>
          <PDATextarea label="Notas" value={form.notas} onChange={(e) => setForm({ ...form, notas: e.target.value })} rows={3} />
          <div className="flex gap-2 justify-end mt-2">
            <PDAButton variant="secondary" onClick={() => setShowModal(false)}>Cancelar</PDAButton>
            <PDAButton onClick={handleSave}>Guardar</PDAButton>
          </div>
        </div>
      </PDAModal>
    </div>
  )
}

// ============================================================================
// MULTAS SECTION
// ============================================================================

function MultasSection() {
  const { serverId, user } = useAuth()
  const [multas, setMultas] = useState<(Multa & { ciudadano?: Ciudadano })[]>([])
  const [ciudadanos, setCiudadanos] = useState<Ciudadano[]>([])
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ ciudadano_id: "", motivo: "", monto: "" })

  const loadData = useCallback(async () => {
    if (!serverId) return
    const supabase = getSupabase()
    const [m, c] = await Promise.all([
      supabase.from("multas").select("*, ciudadanos(*)").eq("servidor_id", serverId).order("fecha", { ascending: false }),
      supabase.from("ciudadanos").select("*").eq("servidor_id", serverId).order("apellido")
    ])
    if (m.data) setMultas(m.data.map((x: any) => ({ ...x, ciudadano: x.ciudadanos })))
    if (c.data) setCiudadanos(c.data)
  }, [serverId])

  useEffect(() => { loadData() }, [loadData])

  const handleSave = async () => {
    if (!serverId || !user) return
    const supabase = getSupabase()
    await supabase.from("multas").insert({
      servidor_id: serverId,
      ciudadano_id: form.ciudadano_id,
      oficial_id: user.id,
      motivo: form.motivo,
      monto: parseFloat(form.monto),
      pagada: false,
      fecha: new Date().toISOString()
    })
    setShowModal(false)
    setForm({ ciudadano_id: "", motivo: "", monto: "" })
    loadData()
  }

  const togglePagada = async (m: Multa) => {
    const supabase = getSupabase()
    await supabase.from("multas").update({ pagada: !m.pagada }).eq("id", m.id)
    loadData()
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <h1 className="text-2xl font-bold text-[var(--pda-text)]">Multas</h1>
        <PDAButton onClick={() => setShowModal(true)}><Plus className="w-4 h-4 mr-2" />Nueva Multa</PDAButton>
      </div>

      <div className="grid gap-4">
        {multas.map(m => (
          <PDACard key={m.id}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-[var(--pda-text)]">
                    {m.ciudadano?.nombre} {m.ciudadano?.apellido}
                  </h3>
                  <Badge variant={m.pagada ? "success" : "warning"}>
                    {m.pagada ? "Pagada" : "Pendiente"}
                  </Badge>
                </div>
                <p className="text-sm text-[var(--pda-text-secondary)]">{m.motivo}</p>
                <div className="flex gap-4 mt-2 text-sm">
                  <span className="text-[var(--pda-accent)] font-semibold">${m.monto}</span>
                  <span className="text-[var(--pda-text-secondary)]">{new Date(m.fecha).toLocaleDateString()}</span>
                </div>
              </div>
              <PDAButton variant={m.pagada ? "secondary" : "success"} size="sm" onClick={() => togglePagada(m)}>
                {m.pagada ? "Marcar Pendiente" : "Marcar Pagada"}
              </PDAButton>
            </div>
          </PDACard>
        ))}
        {multas.length === 0 && <p className="text-center text-[var(--pda-text-secondary)] py-8">No hay multas registradas</p>}
      </div>

      <PDAModal isOpen={showModal} onClose={() => setShowModal(false)} title="Nueva Multa">
        <div className="flex flex-col gap-4">
          <PDASelect
            label="Ciudadano"
            value={form.ciudadano_id}
            onChange={(e) => setForm({ ...form, ciudadano_id: e.target.value })}
            options={[{ value: "", label: "Seleccionar..." }, ...ciudadanos.map(c => ({ value: c.id, label: `${c.nombre} ${c.apellido}` }))]}
          />
          <PDAInput label="Motivo" value={form.motivo} onChange={(e) => setForm({ ...form, motivo: e.target.value })} />
          <PDAInput label="Monto ($)" type="number" value={form.monto} onChange={(e) => setForm({ ...form, monto: e.target.value })} />
          <div className="flex gap-2 justify-end mt-2">
            <PDAButton variant="secondary" onClick={() => setShowModal(false)}>Cancelar</PDAButton>
            <PDAButton onClick={handleSave}>Guardar</PDAButton>
          </div>
        </div>
      </PDAModal>
    </div>
  )
}

// ============================================================================
// ARRESTOS SECTION
// ============================================================================

function ArrestosSection() {
  const { serverId, user } = useAuth()
  const [arrestos, setArrestos] = useState<(Arresto & { ciudadano?: Ciudadano })[]>([])
  const [ciudadanos, setCiudadanos] = useState<Ciudadano[]>([])
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ ciudadano_id: "", cargos: "", tiempo_condena: "", notas: "" })

  const loadData = useCallback(async () => {
    if (!serverId) return
    const supabase = getSupabase()
    const [a, c] = await Promise.all([
      supabase.from("arrestos").select("*, ciudadanos(*)").eq("servidor_id", serverId).order("fecha", { ascending: false }),
      supabase.from("ciudadanos").select("*").eq("servidor_id", serverId).order("apellido")
    ])
    if (a.data) setArrestos(a.data.map((x: any) => ({ ...x, ciudadano: x.ciudadanos })))
    if (c.data) setCiudadanos(c.data)
  }, [serverId])

  useEffect(() => { loadData() }, [loadData])

  const handleSave = async () => {
    if (!serverId || !user) return
    const supabase = getSupabase()
    await supabase.from("arrestos").insert({
      servidor_id: serverId,
      ciudadano_id: form.ciudadano_id,
      oficial_id: user.id,
      cargos: form.cargos,
      tiempo_condena: parseInt(form.tiempo_condena),
      notas: form.notas,
      fecha: new Date().toISOString()
    })
    setShowModal(false)
    setForm({ ciudadano_id: "", cargos: "", tiempo_condena: "", notas: "" })
    loadData()
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <h1 className="text-2xl font-bold text-[var(--pda-text)]">Arrestos</h1>
        <PDAButton onClick={() => setShowModal(true)}><Plus className="w-4 h-4 mr-2" />Nuevo Arresto</PDAButton>
      </div>

      <div className="grid gap-4">
        {arrestos.map(a => (
          <PDACard key={a.id}>
            <div className="flex flex-col gap-2">
              <h3 className="font-semibold text-[var(--pda-text)]">{a.ciudadano?.nombre} {a.ciudadano?.apellido}</h3>
              <p className="text-sm text-[var(--pda-text-secondary)]">{a.cargos}</p>
              <div className="flex gap-4 text-sm">
                <span className="text-[var(--pda-danger)]">{a.tiempo_condena} meses</span>
                <span className="text-[var(--pda-text-secondary)]">{new Date(a.fecha).toLocaleDateString()}</span>
              </div>
            </div>
          </PDACard>
        ))}
        {arrestos.length === 0 && <p className="text-center text-[var(--pda-text-secondary)] py-8">No hay arrestos registrados</p>}
      </div>

      <PDAModal isOpen={showModal} onClose={() => setShowModal(false)} title="Nuevo Arresto">
        <div className="flex flex-col gap-4">
          <PDASelect
            label="Ciudadano"
            value={form.ciudadano_id}
            onChange={(e) => setForm({ ...form, ciudadano_id: e.target.value })}
            options={[{ value: "", label: "Seleccionar..." }, ...ciudadanos.map(c => ({ value: c.id, label: `${c.nombre} ${c.apellido}` }))]}
          />
          <PDATextarea label="Cargos" value={form.cargos} onChange={(e) => setForm({ ...form, cargos: e.target.value })} rows={3} />
          <PDAInput label="Tiempo de Condena (meses)" type="number" value={form.tiempo_condena} onChange={(e) => setForm({ ...form, tiempo_condena: e.target.value })} />
          <PDATextarea label="Notas" value={form.notas} onChange={(e) => setForm({ ...form, notas: e.target.value })} rows={2} />
          <div className="flex gap-2 justify-end mt-2">
            <PDAButton variant="secondary" onClick={() => setShowModal(false)}>Cancelar</PDAButton>
            <PDAButton onClick={handleSave}>Guardar</PDAButton>
          </div>
        </div>
      </PDAModal>
    </div>
  )
}

// ============================================================================
// LLAMADAS 911 SECTION
// ============================================================================

function LlamadasSection({ onCountChange }: { onCountChange: (count: number) => void }) {
  const { serverId, user } = useAuth()
  const [llamadas, setLlamadas] = useState<Llamada[]>([])
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ tipo: "emergencia", ubicacion: "", descripcion: "" })

  const loadData = useCallback(async () => {
    if (!serverId) return
    const supabase = getSupabase()
    const { data } = await supabase.from("llamadas").select("*").eq("servidor_id", serverId).order("fecha", { ascending: false })
    if (data) {
      setLlamadas(data)
      onCountChange(data.filter(l => l.estado === "pendiente").length)
    }
  }, [serverId, onCountChange])

  useEffect(() => { loadData() }, [loadData])

  const handleSave = async () => {
    if (!serverId) return
    const supabase = getSupabase()
    await supabase.from("llamadas").insert({
      servidor_id: serverId,
      tipo: form.tipo,
      ubicacion: form.ubicacion,
      descripcion: form.descripcion,
      estado: "pendiente",
      fecha: new Date().toISOString()
    })
    setShowModal(false)
    setForm({ tipo: "emergencia", ubicacion: "", descripcion: "" })
    loadData()
  }

  const updateEstado = async (l: Llamada, estado: Llamada["estado"]) => {
    const supabase = getSupabase()
    await supabase.from("llamadas").update({ 
      estado, 
      oficial_asignado_id: estado === "en_curso" ? user?.id : l.oficial_asignado_id 
    }).eq("id", l.id)
    loadData()
  }

  const getEstadoColor = (estado: string) => {
    if (estado === "pendiente") return "danger"
    if (estado === "en_curso") return "warning"
    return "success"
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <h1 className="text-2xl font-bold text-[var(--pda-text)]">Llamadas 911</h1>
        <PDAButton onClick={() => setShowModal(true)}><Plus className="w-4 h-4 mr-2" />Nueva Llamada</PDAButton>
      </div>

      <div className="grid gap-4">
        {llamadas.map(l => (
          <PDACard key={l.id}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-[var(--pda-text)] uppercase">{l.tipo}</h3>
                  <Badge variant={getEstadoColor(l.estado)}>{l.estado.replace("_", " ")}</Badge>
                </div>
                <p className="text-sm text-[var(--pda-text-secondary)] flex items-center gap-1 mt-1">
                  <MapPin className="w-4 h-4" />{l.ubicacion}
                </p>
                <p className="text-sm text-[var(--pda-text-secondary)] mt-1">{l.descripcion}</p>
              </div>
              <div className="flex gap-2">
                {l.estado === "pendiente" && (
                  <PDAButton size="sm" onClick={() => updateEstado(l, "en_curso")}>Atender</PDAButton>
                )}
                {l.estado === "en_curso" && (
                  <PDAButton variant="success" size="sm" onClick={() => updateEstado(l, "completada")}>Completar</PDAButton>
                )}
              </div>
            </div>
          </PDACard>
        ))}
        {llamadas.length === 0 && <p className="text-center text-[var(--pda-text-secondary)] py-8">No hay llamadas registradas</p>}
      </div>

      <PDAModal isOpen={showModal} onClose={() => setShowModal(false)} title="Nueva Llamada 911">
        <div className="flex flex-col gap-4">
          <PDASelect
            label="Tipo"
            value={form.tipo}
            onChange={(e) => setForm({ ...form, tipo: e.target.value })}
            options={[
              { value: "emergencia", label: "Emergencia" },
              { value: "robo", label: "Robo" },
              { value: "asalto", label: "Asalto" },
              { value: "accidente", label: "Accidente" },
              { value: "disturbio", label: "Disturbio" },
              { value: "otro", label: "Otro" }
            ]}
          />
          <PDAInput label="Ubicación" value={form.ubicacion} onChange={(e) => setForm({ ...form, ubicacion: e.target.value })} />
          <PDATextarea label="Descripción" value={form.descripcion} onChange={(e) => setForm({ ...form, descripcion: e.target.value })} rows={3} />
          <div className="flex gap-2 justify-end mt-2">
            <PDAButton variant="secondary" onClick={() => setShowModal(false)}>Cancelar</PDAButton>
            <PDAButton onClick={handleSave}>Registrar</PDAButton>
          </div>
        </div>
      </PDAModal>
    </div>
  )
}

// ============================================================================
// BOLO SECTION
// ============================================================================

function BOLOSection() {
  const { serverId, user } = useAuth()
  const [bolos, setBOLOs] = useState<BOLO[]>([])
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ tipo: "persona" as "persona" | "vehiculo", descripcion: "" })

  const loadData = useCallback(async () => {
    if (!serverId) return
    const supabase = getSupabase()
    const { data } = await supabase.from("bolos").select("*").eq("servidor_id", serverId).order("fecha", { ascending: false })
    if (data) setBOLOs(data)
  }, [serverId])

  useEffect(() => { loadData() }, [loadData])

  const handleSave = async () => {
    if (!serverId || !user) return
    const supabase = getSupabase()
    await supabase.from("bolos").insert({
      servidor_id: serverId,
      tipo: form.tipo,
      descripcion: form.descripcion,
      activo: true,
      creado_por_id: user.id,
      fecha: new Date().toISOString()
    })
    setShowModal(false)
    setForm({ tipo: "persona", descripcion: "" })
    loadData()
  }

  const toggleActivo = async (b: BOLO) => {
    const supabase = getSupabase()
    await supabase.from("bolos").update({ activo: !b.activo }).eq("id", b.id)
    loadData()
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <h1 className="text-2xl font-bold text-[var(--pda-text)]">BOLO (Be On Look Out)</h1>
        <PDAButton onClick={() => setShowModal(true)}><Plus className="w-4 h-4 mr-2" />Nuevo BOLO</PDAButton>
      </div>

      <div className="grid gap-4">
        {bolos.map(b => (
          <PDACard key={b.id}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  {b.tipo === "persona" ? <User className="w-5 h-5 text-[var(--pda-accent)]" /> : <Car className="w-5 h-5 text-[var(--pda-accent)]" />}
                  <h3 className="font-semibold text-[var(--pda-text)] uppercase">{b.tipo}</h3>
                  <Badge variant={b.activo ? "danger" : "default"}>{b.activo ? "ACTIVO" : "Inactivo"}</Badge>
                </div>
                <p className="text-sm text-[var(--pda-text-secondary)] mt-2">{b.descripcion}</p>
                <p className="text-xs text-[var(--pda-muted)] mt-1">{new Date(b.fecha).toLocaleString()}</p>
              </div>
              <PDAButton variant={b.activo ? "danger" : "success"} size="sm" onClick={() => toggleActivo(b)}>
                {b.activo ? "Desactivar" : "Activar"}
              </PDAButton>
            </div>
          </PDACard>
        ))}
        {bolos.length === 0 && <p className="text-center text-[var(--pda-text-secondary)] py-8">No hay BOLOs registrados</p>}
      </div>

      <PDAModal isOpen={showModal} onClose={() => setShowModal(false)} title="Nuevo BOLO">
        <div className="flex flex-col gap-4">
          <PDASelect
            label="Tipo"
            value={form.tipo}
            onChange={(e) => setForm({ ...form, tipo: e.target.value as "persona" | "vehiculo" })}
            options={[{ value: "persona", label: "Persona" }, { value: "vehiculo", label: "Vehículo" }]}
          />
          <PDATextarea label="Descripción" placeholder="Descripción detallada..." value={form.descripcion} onChange={(e) => setForm({ ...form, descripcion: e.target.value })} rows={4} />
          <div className="flex gap-2 justify-end mt-2">
            <PDAButton variant="secondary" onClick={() => setShowModal(false)}>Cancelar</PDAButton>
            <PDAButton onClick={handleSave}>Emitir BOLO</PDAButton>
          </div>
        </div>
      </PDAModal>
    </div>
  )
}

// ============================================================================
// DENUNCIAS SECTION
// ============================================================================

function DenunciasSection() {
  const { serverId } = useAuth()
  const [denuncias, setDenuncias] = useState<Denuncia[]>([])
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ descripcion: "" })

  const loadData = useCallback(async () => {
    if (!serverId) return
    const supabase = getSupabase()
    const { data } = await supabase.from("denuncias").select("*").eq("servidor_id", serverId).order("fecha", { ascending: false })
    if (data) setDenuncias(data)
  }, [serverId])

  useEffect(() => { loadData() }, [loadData])

  const handleSave = async () => {
    if (!serverId) return
    const supabase = getSupabase()
    await supabase.from("denuncias").insert({
      servidor_id: serverId,
      descripcion: form.descripcion,
      estado: "pendiente",
      fecha: new Date().toISOString()
    })
    setShowModal(false)
    setForm({ descripcion: "" })
    loadData()
  }

  const updateEstado = async (d: Denuncia, estado: Denuncia["estado"]) => {
    const supabase = getSupabase()
    await supabase.from("denuncias").update({ estado }).eq("id", d.id)
    loadData()
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <h1 className="text-2xl font-bold text-[var(--pda-text)]">Denuncias</h1>
        <PDAButton onClick={() => setShowModal(true)}><Plus className="w-4 h-4 mr-2" />Nueva Denuncia</PDAButton>
      </div>

      <div className="grid gap-4">
        {denuncias.map(d => (
          <PDACard key={d.id}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <Badge variant={d.estado === "pendiente" ? "warning" : d.estado === "investigando" ? "default" : "success"}>
                    {d.estado}
                  </Badge>
                </div>
                <p className="text-sm text-[var(--pda-text)] mt-2">{d.descripcion}</p>
                <p className="text-xs text-[var(--pda-muted)] mt-1">{new Date(d.fecha).toLocaleString()}</p>
              </div>
              <div className="flex gap-2">
                {d.estado === "pendiente" && <PDAButton size="sm" onClick={() => updateEstado(d, "investigando")}>Investigar</PDAButton>}
                {d.estado === "investigando" && <PDAButton variant="success" size="sm" onClick={() => updateEstado(d, "cerrada")}>Cerrar</PDAButton>}
              </div>
            </div>
          </PDACard>
        ))}
        {denuncias.length === 0 && <p className="text-center text-[var(--pda-text-secondary)] py-8">No hay denuncias registradas</p>}
      </div>

      <PDAModal isOpen={showModal} onClose={() => setShowModal(false)} title="Nueva Denuncia">
        <div className="flex flex-col gap-4">
          <PDATextarea label="Descripción" value={form.descripcion} onChange={(e) => setForm({ ...form, descripcion: e.target.value })} rows={4} />
          <div className="flex gap-2 justify-end mt-2">
            <PDAButton variant="secondary" onClick={() => setShowModal(false)}>Cancelar</PDAButton>
            <PDAButton onClick={handleSave}>Registrar</PDAButton>
          </div>
        </div>
      </PDAModal>
    </div>
  )
}

// ============================================================================
// INVESTIGACIONES SECTION
// ============================================================================

function InvestigacionesSection() {
  const { serverId, user } = useAuth()
  const [investigaciones, setInvestigaciones] = useState<Investigacion[]>([])
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ titulo: "", descripcion: "" })

  const loadData = useCallback(async () => {
    if (!serverId) return
    const supabase = getSupabase()
    const { data } = await supabase.from("investigaciones").select("*").eq("servidor_id", serverId).order("fecha", { ascending: false })
    if (data) setInvestigaciones(data)
  }, [serverId])

  useEffect(() => { loadData() }, [loadData])

  const handleSave = async () => {
    if (!serverId || !user) return
    const supabase = getSupabase()
    await supabase.from("investigaciones").insert({
      servidor_id: serverId,
      titulo: form.titulo,
      descripcion: form.descripcion,
      estado: "abierta",
      oficial_cargo_id: user.id,
      fecha: new Date().toISOString()
    })
    setShowModal(false)
    setForm({ titulo: "", descripcion: "" })
    loadData()
  }

  const updateEstado = async (i: Investigacion, estado: Investigacion["estado"]) => {
    const supabase = getSupabase()
    await supabase.from("investigaciones").update({ estado }).eq("id", i.id)
    loadData()
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <h1 className="text-2xl font-bold text-[var(--pda-text)]">Investigaciones</h1>
        <PDAButton onClick={() => setShowModal(true)}><Plus className="w-4 h-4 mr-2" />Nueva Investigación</PDAButton>
      </div>

      <div className="grid gap-4">
        {investigaciones.map(i => (
          <PDACard key={i.id}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-[var(--pda-text)]">{i.titulo}</h3>
                  <Badge variant={i.estado === "abierta" ? "warning" : i.estado === "en_progreso" ? "default" : "success"}>
                    {i.estado.replace("_", " ")}
                  </Badge>
                </div>
                <p className="text-sm text-[var(--pda-text-secondary)] mt-2">{i.descripcion}</p>
                <p className="text-xs text-[var(--pda-muted)] mt-1">{new Date(i.fecha).toLocaleString()}</p>
              </div>
              <div className="flex gap-2">
                {i.estado === "abierta" && <PDAButton size="sm" onClick={() => updateEstado(i, "en_progreso")}>En Progreso</PDAButton>}
                {i.estado === "en_progreso" && <PDAButton variant="success" size="sm" onClick={() => updateEstado(i, "cerrada")}>Cerrar</PDAButton>}
              </div>
            </div>
          </PDACard>
        ))}
        {investigaciones.length === 0 && <p className="text-center text-[var(--pda-text-secondary)] py-8">No hay investigaciones</p>}
      </div>

      <PDAModal isOpen={showModal} onClose={() => setShowModal(false)} title="Nueva Investigación">
        <div className="flex flex-col gap-4">
          <PDAInput label="Título" value={form.titulo} onChange={(e) => setForm({ ...form, titulo: e.target.value })} />
          <PDATextarea label="Descripción" value={form.descripcion} onChange={(e) => setForm({ ...form, descripcion: e.target.value })} rows={4} />
          <div className="flex gap-2 justify-end mt-2">
            <PDAButton variant="secondary" onClick={() => setShowModal(false)}>Cancelar</PDAButton>
            <PDAButton onClick={handleSave}>Crear</PDAButton>
          </div>
        </div>
      </PDAModal>
    </div>
  )
}

// ============================================================================
// SERVICIO SECTION
// ============================================================================

function ServicioSection() {
  const { serverId, user, activeServiceId, setActiveServiceId, checkActiveService } = useAuth()
  const [servicio, setServicio] = useState<Servicio | null>(null)

  const loadData = useCallback(async () => {
    if (!serverId || !user) return
    const supabase = getSupabase()
    const { data } = await supabase.from("servicios").select("*").eq("servidor_id", serverId).eq("oficial_id", user.id).eq("estado", "activo").single()
    setServicio(data || null)
  }, [serverId, user])

  useEffect(() => { loadData() }, [loadData])

  const iniciarServicio = async () => {
    if (!serverId || !user) return
    const supabase = getSupabase()
    const { data } = await supabase.from("servicios").insert({
      servidor_id: serverId,
      oficial_id: user.id,
      hora_entrada: new Date().toISOString(),
      estado: "activo"
    }).select().single()
    if (data) {
      setServicio(data)
      setActiveServiceId(data.id)
    }
  }

  const finalizarServicio = async () => {
    if (!servicio) return
    const supabase = getSupabase()
    await supabase.from("servicios").update({
      hora_salida: new Date().toISOString(),
      estado: "finalizado"
    }).eq("id", servicio.id)
    setServicio(null)
    setActiveServiceId(null)
  }

  const togglePausa = async () => {
    if (!servicio) return
    const supabase = getSupabase()
    await supabase.from("servicios").update({
      estado: servicio.estado === "activo" ? "pausa" : "activo"
    }).eq("id", servicio.id)
    loadData()
  }

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-2xl font-bold text-[var(--pda-text)]">Mi Servicio</h1>

      <PDACard className="text-center">
        <div className="flex flex-col items-center gap-4 py-6">
          <div className={`w-20 h-20 rounded-full flex items-center justify-center ${servicio ? "bg-[var(--pda-success)]" : "bg-[var(--pda-muted)]"}`}>
            <Power className="w-10 h-10 text-white" />
          </div>
          
          <div>
            <p className="text-lg font-semibold text-[var(--pda-text)]">
              {servicio ? (servicio.estado === "pausa" ? "En Pausa" : "En Servicio") : "Fuera de Servicio"}
            </p>
            {servicio && (
              <p className="text-sm text-[var(--pda-text-secondary)]">
                Inicio: {new Date(servicio.hora_entrada).toLocaleTimeString()}
              </p>
            )}
          </div>

          <div className="flex gap-3">
            {!servicio ? (
              <PDAButton onClick={iniciarServicio}><Power className="w-4 h-4 mr-2" />Iniciar Servicio</PDAButton>
            ) : (
              <>
                <PDAButton variant={servicio.estado === "pausa" ? "success" : "secondary"} onClick={togglePausa}>
                  <Coffee className="w-4 h-4 mr-2" />{servicio.estado === "pausa" ? "Reanudar" : "Pausa"}
                </PDAButton>
                <PDAButton variant="danger" onClick={finalizarServicio}>
                  <Power className="w-4 h-4 mr-2" />Finalizar
                </PDAButton>
              </>
            )}
          </div>
        </div>
      </PDACard>

      <PDACard>
        <h3 className="font-semibold text-[var(--pda-text)] mb-4">Información del Oficial</h3>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-[var(--pda-text-secondary)]">Nombre</p>
            <p className="text-[var(--pda-text)]">{user?.nombre_completo}</p>
          </div>
          <div>
            <p className="text-[var(--pda-text-secondary)]">Rango</p>
            <p className="text-[var(--pda-text)]">{user?.rango}</p>
          </div>
          <div>
            <p className="text-[var(--pda-text-secondary)]">Placa</p>
            <p className="text-[var(--pda-text)]">#{user?.placa}</p>
          </div>
          <div>
            <p className="text-[var(--pda-text-secondary)]">Rol</p>
            <p className="text-[var(--pda-text)] capitalize">{user?.rol}</p>
          </div>
        </div>
      </PDACard>
    </div>
  )
}

// ============================================================================
// ADMIN PANEL
// ============================================================================

function AdminPanel() {
  const { serverId } = useAuth()
  const [stats, setStats] = useState({ usuarios: 0, ciudadanos: 0, multas: 0, arrestos: 0 })

  useEffect(() => {
    async function loadStats() {
      if (!serverId) return
      const supabase = getSupabase()
      const [u, c, m, a] = await Promise.all([
        supabase.from("usuarios").select("id", { count: "exact", head: true }).eq("servidor_id", serverId),
        supabase.from("ciudadanos").select("id", { count: "exact", head: true }).eq("servidor_id", serverId),
        supabase.from("multas").select("id", { count: "exact", head: true }).eq("servidor_id", serverId),
        supabase.from("arrestos").select("id", { count: "exact", head: true }).eq("servidor_id", serverId)
      ])
      setStats({ usuarios: u.count || 0, ciudadanos: c.count || 0, multas: m.count || 0, arrestos: a.count || 0 })
    }
    loadStats()
  }, [serverId])

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-2xl font-bold text-[var(--pda-text)]">Panel de Administración</h1>
      
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={UserCog} label="Usuarios" value={stats.usuarios} color="bg-blue-500" />
        <StatCard icon={Users} label="Ciudadanos" value={stats.ciudadanos} color="bg-green-500" />
        <StatCard icon={FileText} label="Multas" value={stats.multas} color="bg-yellow-500" />
        <StatCard icon={Gavel} label="Arrestos" value={stats.arrestos} color="bg-red-500" />
      </div>
    </div>
  )
}

// ============================================================================
// ADMIN USUARIOS
// ============================================================================

function AdminUsuarios() {
  const { serverId } = useAuth()
  const [usuarios, setUsuarios] = useState<Usuario[]>([])
  const [showModal, setShowModal] = useState(false)
  const [editing, setEditing] = useState<Usuario | null>(null)
  const [form, setForm] = useState({ username: "", password: "", nombre_completo: "", rango: "", placa: "", rol: "officer" as Usuario["rol"] })

  const loadData = useCallback(async () => {
    if (!serverId) return
    const supabase = getSupabase()
    const { data } = await supabase.from("usuarios").select("*").eq("servidor_id", serverId).order("nombre_completo")
    if (data) setUsuarios(data)
  }, [serverId])

  useEffect(() => { loadData() }, [loadData])

  const handleSave = async () => {
    if (!serverId) return
    const supabase = getSupabase()
    
    if (editing) {
      const update: any = { ...form }
      if (!form.password) delete update.password
      await supabase.from("usuarios").update(update).eq("id", editing.id)
    } else {
      await supabase.from("usuarios").insert({ ...form, servidor_id: serverId, activo: true })
    }

    setShowModal(false)
    setEditing(null)
    setForm({ username: "", password: "", nombre_completo: "", rango: "", placa: "", rol: "officer" })
    loadData()
  }

  const toggleActivo = async (u: Usuario) => {
    const supabase = getSupabase()
    await supabase.from("usuarios").update({ activo: !u.activo }).eq("id", u.id)
    loadData()
  }

  const openEdit = (u: Usuario) => {
    setEditing(u)
    setForm({ username: u.username, password: "", nombre_completo: u.nombre_completo, rango: u.rango, placa: u.placa, rol: u.rol })
    setShowModal(true)
  }

  const openNew = () => {
    setEditing(null)
    setForm({ username: "", password: "", nombre_completo: "", rango: "", placa: "", rol: "officer" })
    setShowModal(true)
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <h1 className="text-2xl font-bold text-[var(--pda-text)]">Gestión de Usuarios</h1>
        <PDAButton onClick={openNew}><Plus className="w-4 h-4 mr-2" />Nuevo Usuario</PDAButton>
      </div>

      <div className="grid gap-4">
        {usuarios.map(u => (
          <PDACard key={u.id}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-[var(--pda-text)]">{u.nombre_completo}</h3>
                  <Badge variant={u.activo ? "success" : "danger"}>{u.activo ? "Activo" : "Inactivo"}</Badge>
                  <Badge>{u.rol}</Badge>
                </div>
                <p className="text-sm text-[var(--pda-text-secondary)]">{u.rango} - #{u.placa}</p>
                <p className="text-xs text-[var(--pda-muted)]">@{u.username}</p>
              </div>
              <div className="flex gap-2">
                <PDAButton variant="ghost" size="sm" onClick={() => openEdit(u)}><Pencil className="w-4 h-4" /></PDAButton>
                <PDAButton variant={u.activo ? "danger" : "success"} size="sm" onClick={() => toggleActivo(u)}>
                  {u.activo ? "Desactivar" : "Activar"}
                </PDAButton>
              </div>
            </div>
          </PDACard>
        ))}
      </div>

      <PDAModal isOpen={showModal} onClose={() => setShowModal(false)} title={editing ? "Editar Usuario" : "Nuevo Usuario"}>
        <div className="flex flex-col gap-4">
          <PDAInput label="Username" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />
          <PDAInput label={editing ? "Nueva Contraseña (dejar vacío para mantener)" : "Contraseña"} type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          <PDAInput label="Nombre Completo" value={form.nombre_completo} onChange={(e) => setForm({ ...form, nombre_completo: e.target.value })} />
          <div className="grid grid-cols-2 gap-4">
            <PDAInput label="Rango" value={form.rango} onChange={(e) => setForm({ ...form, rango: e.target.value })} />
            <PDAInput label="Placa" value={form.placa} onChange={(e) => setForm({ ...form, placa: e.target.value })} />
          </div>
          <PDASelect
            label="Rol"
            value={form.rol}
            onChange={(e) => setForm({ ...form, rol: e.target.value as Usuario["rol"] })}
            options={[
              { value: "officer", label: "Oficial" },
              { value: "supervisor", label: "Supervisor" },
              { value: "admin", label: "Administrador" }
            ]}
          />
          <div className="flex gap-2 justify-end mt-2">
            <PDAButton variant="secondary" onClick={() => setShowModal(false)}>Cancelar</PDAButton>
            <PDAButton onClick={handleSave}>Guardar</PDAButton>
          </div>
        </div>
      </PDAModal>
    </div>
  )
}

// ============================================================================
// AUDITORIA
// ============================================================================

function AuditoriaSection() {
  const { serverId } = useAuth()
  const [logs, setLogs] = useState<any[]>([])

  useEffect(() => {
    async function loadLogs() {
      if (!serverId) return
      const supabase = getSupabase()
      const { data } = await supabase
        .from("auditoria")
        .select("*, usuarios(nombre_completo)")
        .eq("servidor_id", serverId)
        .order("created_at", { ascending: false })
        .limit(100)
      if (data) setLogs(data)
    }
    loadLogs()
  }, [serverId])

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-2xl font-bold text-[var(--pda-text)]">Auditoría</h1>

      <div className="flex flex-col gap-2">
        {logs.map(l => (
          <PDACard key={l.id} className="py-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <div className="flex items-center gap-2">
                  <Badge>{l.accion}</Badge>
                  <span className="text-sm text-[var(--pda-text)]">{l.usuarios?.nombre_completo}</span>
                </div>
                <p className="text-sm text-[var(--pda-text-secondary)]">{l.detalles}</p>
              </div>
              <span className="text-xs text-[var(--pda-muted)]">{new Date(l.created_at).toLocaleString()}</span>
            </div>
          </PDACard>
        ))}
        {logs.length === 0 && <p className="text-center text-[var(--pda-text-secondary)] py-8">No hay registros</p>}
      </div>
    </div>
  )
}

// ============================================================================
// MAIN APP
// ============================================================================

function MainApp() {
  const { user, checkActiveService } = useAuth()
  const [activeSection, setActiveSection] = useState<SectionName>("dashboard")
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [llamadasCount, setLlamadasCount] = useState(0)

  const handleLoginSuccess = useCallback(() => {
    checkActiveService()
    setActiveSection("dashboard")
  }, [checkActiveService])

  if (!user) {
    return <LoginScreen onSuccess={handleLoginSuccess} />
  }

  const renderSection = () => {
    switch (activeSection) {
      case "dashboard": return <DashboardSection />
      case "ciudadanos": return <CiudadanosSection />
      case "vehiculos": return <VehiculosSection />
      case "multas": return <MultasSection />
      case "arrestos": return <ArrestosSection />
      case "llamadas": return <LlamadasSection onCountChange={setLlamadasCount} />
      case "bolo": return <BOLOSection />
      case "denuncias": return <DenunciasSection />
      case "investigaciones": return <InvestigacionesSection />
      case "servicio": return <ServicioSection />
      case "admin": return <AdminPanel />
      case "admin-usuarios": return <AdminUsuarios />
      case "auditoria": return <AuditoriaSection />
      default: return <DashboardSection />
    }
  }

  return (
    <div className="min-h-screen bg-[var(--pda-primary)]">
      <Header onToggleSidebar={() => setSidebarOpen(!sidebarOpen)} />
      <div className="flex">
        <Sidebar
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          activeSection={activeSection}
          onSectionChange={setActiveSection}
          llamadasCount={llamadasCount}
        />
        <main className="flex-1 p-6 overflow-auto">
          {renderSection()}
        </main>
      </div>
    </div>
  )
}

// ============================================================================
// EXPORT
// ============================================================================

export default function PDASystem() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  )
}
